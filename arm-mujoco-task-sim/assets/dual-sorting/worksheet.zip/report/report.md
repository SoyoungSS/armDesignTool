# 模型生成报告

模型：worksheet_reference；等级：concept_simulation。

所有坐标为右手系，m/kg/rad；RPY=Rz Ry Rx。基座安装只应用于 world→base 一次。几何零位与初始关节值分开保存。

| 目标 | 生成/检查状态 | 运行时 |
|---|---|---|
| urdf | static_checked | pending |
| mujoco | failed | passed |

零件级碰撞复核：failed。姿态覆盖、零件配合和接触面偏差见 [validation.json](validation.json) 的 collision_review。
优先检查 J3_link/beam / J5_link/housing，姿态 J4_upper。

[机械臂初始姿态预览](../preview.png)

## 外形生成

规则：rounded-shell-v2。整链比例、肩肘腕模组空间约束、多截面连续外壳、圆肩端盖和分区材质；使用 NumPy 原生生成，没有 CAD 依赖。

外壳模板是概念设计推定；每个实体部件闭合，但同一连杆的壳体/端盖可局部相交，未执行 CAD 布尔融合。碰撞使用中央梁盒体与模组圆柱近似，圆滑过渡不等同于精确接触表面。实体重叠不重复计重。详细规则、尺寸与模板见 appearance_design.json 和下方逐连杆记录。


## 关节模组布置

规则：axis-module-layout-v1；状态：resolved。原始运动学帧保持不变，自转固定壳归上游连杆、输出套筒归下游连杆，模组退让不移动已有质量/质心。

| 组合 | 模板 | 自转退让 m | 摆动侧置 m |
|---|---|---:|---:|

独立模组包络检查：passed。该检查不受仿真碰撞过滤影响，详见 validation.json/module_packing；不等同于全机构可制造性证明。


## 缺项与假设

- Source: examples/models/seven-axis.json. Joint frames, lengths, axes, bounds, individual moving masses and COMs match the worksheet.
- The fixed mount mass is unspecified. Moving inertia is estimated from per-link geometry and translated to each given component COM. Exterior shapes are concept envelopes.
- Effort and speed are assumed simulation limits, not worksheet measurements or motor ratings. The wall-mounted bearing support attaches sideways along +J1.
- This bare-arm model excludes the worksheet 3 kg reference payload. Add the task gripper and dynamic object separately.
- Fixed world-mounted base has no specified mass; moving-body mass and gravity are unchanged.

## 驱动参数

策略：serial-pd-v1；状态：resolved；建议物理步长：0.000234616 s。

SI 参数供 MJCF / USD 共用。角 kp 单位 Nm/rad、kv 单位 Nm·s/rad；移动轴为 N/m、N·s/m。USD 角增益另按每度换算。固定规则和采样证据见 drive_design.json；没有伪造质量、转子惯量、摩擦或重力补偿。

| 关节 | 模式 | kp | kv | 力/矩上限 | 来源 kp / kv |
|---|---|---:|---:|---:|---|
| J1 | position | 156.00495 | 24.390121 | 40 | automatic / automatic |
| J2 | position | 133.03226 | 20.657103 | 35 | automatic / automatic |
| J3 | position | 31.512186 | 3.4430225 | 15 | automatic / automatic |
| J4 | position | 35.590469 | 3.7260558 | 15 | automatic / automatic |
| J5 | position | 2.255625 | 0.14473748 | 5 | automatic / automatic |
| J6 | position | 3.2406565 | 0.1701401 | 5 | automatic / automatic |
| J7 | position | 0.23196407 | 0.011473083 | 3 | automatic / automatic |

MuJoCo 位置驱动验收：passed。以下仅为接触开启的有限姿态结果；静差单独报告，不以稳定代替精度。

| 工况 | 稳定 | 最大尾段峰峰值 | 最大尾段速度 | 最大静差 |
|---|---|---:|---:|---:|
| hold_initial | True | 1.26366e-12 | 9.12279e-12 | 0.0358737 |
| smooth_move | True | 1.13909e-13 | 1.10594e-12 | 0.0347638 |

数值分别使用 rad/m、rad/s或m/s；混合关节的逐轴数值和饱和率详见 validation.json。

## 装配配合体碰撞排除

两种仿真格式共用以下拓扑排除，避免相邻配合壳体互相顶开。共点壳体扩展只跨零平移 revolute/fixed 链，遇移动轴或非零偏移即停止；不自动排除其他穿插。真实 CAD 需另行复核。

- base_link / J1_link：direct joint mating pair
- J1_link / J2_link：direct joint mating pair
- J2_link / J3_link：direct joint mating pair
- J3_link / J4_link：direct joint mating pair
- J4_link / J5_link：direct joint mating pair
- J5_link / J6_link：direct joint mating pair
- J6_link / J7_link：direct joint mating pair

## 连杆生成与质量来源

### base_link

rounded-shell-v2: whole-arm shell and pedestal

```json
{
  "dimensions": {
    "width_m": {
      "value": 0.037,
      "source": "estimated",
      "basis": "whole-chain reach, root-to-tip taper and local span; explicit dimensions take precedence"
    },
    "thickness_m": {
      "value": 0.030339999999999995,
      "source": "estimated",
      "basis": "whole-chain reach, root-to-tip taper and local span; explicit dimensions take precedence"
    },
    "diameter_m": {
      "value": 0.075,
      "source": "design",
      "basis": "whole-chain reach, root-to-tip taper and local span; explicit dimensions take precedence"
    },
    "module_space_cap_m": {
      "value": 0.03150000000000001,
      "source": "estimated",
      "basis": "90% of nearest nonzero installation spacing across coincident frames"
    },
    "axial_width_m": {
      "value": 0.022,
      "source": "design",
      "basis": "whole-chain reach, root-to-tip taper and local span; explicit dimensions take precedence"
    },
    "template": "pedestal",
    "short_span": {
      "value": 0.0,
      "source": "kinematics",
      "basis": "full-scale wrist housing; original frames preserved"
    },
    "bearing_mount_side": {
      "side": 1,
      "plate_offset_m": 0.051069859999999995,
      "bearing_face_distance_m": 0.011694859999999998
    }
  },
  "mass": null,
  "mass_proxy": {
    "kind": "cylinder",
    "size": [
      0.0375,
      0.022
    ],
    "T": [
      [
        0.0,
        1.0,
        0.0,
        0.0
      ],
      [
        -1.0,
        0.0,
        0.0,
        0.0
      ],
      [
        0.0,
        -0.0,
        1.0,
        0.0
      ],
      [
        0.0,
        0.0,
        0.0,
        1.0
      ]
    ]
  }
}
```

### J1_link

rounded-shell-v2: whole-arm shell and elbow_shell

```json
{
  "dimensions": {
    "width_m": {
      "value": 0.021,
      "source": "design",
      "basis": "whole-chain reach, root-to-tip taper and local span; explicit dimensions take precedence"
    },
    "thickness_m": {
      "value": 0.01722,
      "source": "estimated",
      "basis": "whole-chain reach, root-to-tip taper and local span; explicit dimensions take precedence"
    },
    "diameter_m": {
      "value": 0.028350000000000004,
      "source": "estimated",
      "basis": "whole-chain reach, root-to-tip taper and local span; explicit dimensions take precedence"
    },
    "module_space_cap_m": {
      "value": 0.03150000000000001,
      "source": "estimated",
      "basis": "90% of nearest nonzero installation spacing across coincident frames"
    },
    "axial_width_m": {
      "value": 0.01722,
      "source": "estimated",
      "basis": "whole-chain reach, root-to-tip taper and local span; explicit dimensions take precedence"
    },
    "template": "elbow_shell",
    "distal_setback_m": {
      "value": 0.006,
      "source": "design",
      "basis": "whole-chain reach, root-to-tip taper and local span; explicit dimensions take precedence"
    },
    "shell_collision": "central box; rounded end transitions approximated by joint housings, not exact surface collision"
  },
  "mass": {
    "mass_kg": 1.061,
    "com_m": [
      0.0,
      0.0,
      -0.0016493873704052783
    ],
    "inertia_kg_m2": [
      [
        7.128629146845744e-05,
        0.0,
        0.0
      ],
      [
        0.0,
        8.405998876845744e-05,
        0.0
      ],
      [
        0.0,
        0.0,
        6.520980270000001e-05
      ]
    ],
    "sources": [
      "link: known mass distributed on documented proxy translated to supplied COM",
      "joint_output_equivalent: known mass distributed on documented proxy translated to supplied COM"
    ]
  },
  "mass_proxy": {
    "kind": "box",
    "size": [
      0.021,
      0.01722,
      0.014000000000000002
    ],
    "T": [
      [
        -1.0,
        0.0,
        0.0,
        0.0
      ],
      [
        0.0,
        1.0,
        0.0,
        0.0
      ],
      [
        0.0,
        0.0,
        -1.0,
        -0.0175
      ],
      [
        0.0,
        0.0,
        0.0,
        1.0
      ]
    ]
  }
}
```

### J2_link

rounded-shell-v2: whole-arm shell and elbow_shell

```json
{
  "dimensions": {
    "width_m": {
      "value": 0.028,
      "source": "design",
      "basis": "whole-chain reach, root-to-tip taper and local span; explicit dimensions take precedence"
    },
    "thickness_m": {
      "value": 0.022959999999999998,
      "source": "estimated",
      "basis": "whole-chain reach, root-to-tip taper and local span; explicit dimensions take precedence"
    },
    "diameter_m": {
      "value": 0.03150000000000001,
      "source": "estimated",
      "basis": "whole-chain reach, root-to-tip taper and local span; explicit dimensions take precedence"
    },
    "module_space_cap_m": {
      "value": 0.03150000000000001,
      "source": "estimated",
      "basis": "90% of nearest nonzero installation spacing across coincident frames"
    },
    "axial_width_m": {
      "value": 0.022680000000000006,
      "source": "estimated",
      "basis": "whole-chain reach, root-to-tip taper and local span; explicit dimensions take precedence"
    },
    "template": "elbow_shell",
    "distal_setback_m": {
      "value": 0.012,
      "source": "design",
      "basis": "whole-chain reach, root-to-tip taper and local span; explicit dimensions take precedence"
    },
    "shell_collision": "central box; rounded end transitions approximated by joint housings, not exact surface collision"
  },
  "mass": {
    "mass_kg": 0.575,
    "com_m": [
      0.0,
      0.0,
      -0.00391304347826087
    ],
    "inertia_kg_m2": [
      [
        0.00010417898550724638,
        0.0,
        0.0
      ],
      [
        0.0,
        9.187214550724639e-05,
        0.0
      ],
      [
        0.0,
        0.0,
        6.282649333333334e-05
      ]
    ],
    "sources": [
      "link: known mass distributed on documented proxy translated to supplied COM",
      "joint_output_equivalent: known mass distributed on documented proxy translated to supplied COM"
    ]
  },
  "mass_proxy": {
    "kind": "box",
    "size": [
      0.028,
      0.022959999999999998,
      0.020000000000000004
    ],
    "T": [
      [
        -0.0,
        1.0,
        0.0,
        0.0
      ],
      [
        1.0,
        0.0,
        0.0,
        0.0
      ],
      [
        0.0,
        0.0,
        -1.0,
        -0.025
      ],
      [
        0.0,
        0.0,
        0.0,
        1.0
      ]
    ]
  }
}
```

### J3_link

rounded-shell-v2: whole-arm shell and elbow_shell

```json
{
  "dimensions": {
    "width_m": {
      "value": 0.037,
      "source": "estimated",
      "basis": "whole-chain reach, root-to-tip taper and local span; explicit dimensions take precedence"
    },
    "thickness_m": {
      "value": 0.030339999999999995,
      "source": "estimated",
      "basis": "whole-chain reach, root-to-tip taper and local span; explicit dimensions take precedence"
    },
    "diameter_m": {
      "value": 0.045000000000000005,
      "source": "estimated",
      "basis": "whole-chain reach, root-to-tip taper and local span; explicit dimensions take precedence"
    },
    "module_space_cap_m": {
      "value": 0.045000000000000005,
      "source": "estimated",
      "basis": "90% of nearest nonzero installation spacing across coincident frames"
    },
    "axial_width_m": {
      "value": 0.030339999999999995,
      "source": "estimated",
      "basis": "whole-chain reach, root-to-tip taper and local span; explicit dimensions take precedence"
    },
    "template": "elbow_shell",
    "shell_collision": "central box; rounded end transitions approximated by joint housings, not exact surface collision"
  },
  "mass": {
    "mass_kg": 0.705,
    "com_m": [
      0.0,
      0.0,
      -0.03900709219858156
    ],
    "inertia_kg_m2": [
      [
        0.004806998402039006,
        0.0,
        0.0
      ],
      [
        0.0,
        0.004780649943539007,
        0.0
      ],
      [
        0.0,
        0.0,
        0.00013450904149999997
      ]
    ],
    "sources": [
      "link: known mass distributed on documented proxy translated to supplied COM",
      "joint_output_equivalent: known mass distributed on documented proxy translated to supplied COM"
    ]
  },
  "mass_proxy": {
    "kind": "box",
    "size": [
      0.037,
      0.030339999999999995,
      0.20049999999999998
    ],
    "T": [
      [
        -0.0,
        1.0,
        0.0,
        0.0
      ],
      [
        1.0,
        0.0,
        0.0,
        0.0
      ],
      [
        0.0,
        0.0,
        -1.0,
        -0.125
      ],
      [
        0.0,
        0.0,
        0.0,
        1.0
      ]
    ]
  }
}
```

### J4_link

rounded-shell-v2: whole-arm shell and elbow_shell

```json
{
  "dimensions": {
    "width_m": {
      "value": 0.026,
      "source": "design",
      "basis": "whole-chain reach, root-to-tip taper and local span; explicit dimensions take precedence"
    },
    "thickness_m": {
      "value": 0.02132,
      "source": "estimated",
      "basis": "whole-chain reach, root-to-tip taper and local span; explicit dimensions take precedence"
    },
    "diameter_m": {
      "value": 0.0351,
      "source": "estimated",
      "basis": "whole-chain reach, root-to-tip taper and local span; explicit dimensions take precedence"
    },
    "module_space_cap_m": {
      "value": 0.045000000000000005,
      "source": "estimated",
      "basis": "90% of nearest nonzero installation spacing across coincident frames"
    },
    "axial_width_m": {
      "value": 0.02132,
      "source": "estimated",
      "basis": "whole-chain reach, root-to-tip taper and local span; explicit dimensions take precedence"
    },
    "template": "elbow_shell",
    "distal_setback_m": {
      "value": 0.012,
      "source": "design",
      "basis": "whole-chain reach, root-to-tip taper and local span; explicit dimensions take precedence"
    },
    "shell_collision": "central box; rounded end transitions approximated by joint housings, not exact surface collision"
  },
  "mass": {
    "mass_kg": 0.565,
    "com_m": [
      0.0,
      0.0,
      -0.003539823008849558
    ],
    "inertia_kg_m2": [
      [
        8.315505864896756e-05,
        0.0,
        0.0
      ],
      [
        0.0,
        9.358202064896756e-05,
        0.0
      ],
      [
        0.0,
        0.0,
        5.322970466666667e-05
      ]
    ],
    "sources": [
      "link: known mass distributed on documented proxy translated to supplied COM",
      "joint_output_equivalent: known mass distributed on documented proxy translated to supplied COM"
    ]
  },
  "mass_proxy": {
    "kind": "box",
    "size": [
      0.026,
      0.02132,
      0.020000000000000004
    ],
    "T": [
      [
        1.0,
        0.0,
        0.0,
        0.0
      ],
      [
        0.0,
        -1.0,
        0.0,
        0.0
      ],
      [
        0.0,
        0.0,
        -1.0,
        -0.025
      ],
      [
        0.0,
        0.0,
        0.0,
        1.0
      ]
    ]
  }
}
```

### J5_link

rounded-shell-v2: whole-arm shell and elbow_shell

```json
{
  "dimensions": {
    "width_m": {
      "value": 0.037,
      "source": "estimated",
      "basis": "whole-chain reach, root-to-tip taper and local span; explicit dimensions take precedence"
    },
    "thickness_m": {
      "value": 0.030339999999999995,
      "source": "estimated",
      "basis": "whole-chain reach, root-to-tip taper and local span; explicit dimensions take precedence"
    },
    "diameter_m": {
      "value": 0.045000000000000005,
      "source": "estimated",
      "basis": "whole-chain reach, root-to-tip taper and local span; explicit dimensions take precedence"
    },
    "module_space_cap_m": {
      "value": 0.045000000000000005,
      "source": "estimated",
      "basis": "90% of nearest nonzero installation spacing across coincident frames"
    },
    "axial_width_m": {
      "value": 0.030339999999999995,
      "source": "estimated",
      "basis": "whole-chain reach, root-to-tip taper and local span; explicit dimensions take precedence"
    },
    "template": "elbow_shell",
    "shell_collision": "central box; rounded end transitions approximated by joint housings, not exact surface collision"
  },
  "mass": {
    "mass_kg": 0.28200000000000003,
    "com_m": [
      0.0,
      0.0,
      -0.03468085106382979
    ],
    "inertia_kg_m2": [
      [
        0.0007927956515957446,
        0.0,
        0.0
      ],
      [
        0.0,
        0.0007822562681957445,
        0.0
      ],
      [
        0.0,
        0.0,
        5.380361659999998e-05
      ]
    ],
    "sources": [
      "link: known mass distributed on documented proxy translated to supplied COM",
      "joint_output_equivalent: known mass distributed on documented proxy translated to supplied COM"
    ]
  },
  "mass_proxy": {
    "kind": "box",
    "size": [
      0.037,
      0.030339999999999995,
      0.11349999999999999
    ],
    "T": [
      [
        -0.0,
        1.0,
        0.0,
        0.0
      ],
      [
        1.0,
        0.0,
        0.0,
        0.0
      ],
      [
        0.0,
        0.0,
        -1.0,
        -0.0815
      ],
      [
        0.0,
        0.0,
        0.0,
        1.0
      ]
    ]
  }
}
```

### J6_link

rounded-shell-v2: whole-arm shell and elbow_shell

```json
{
  "dimensions": {
    "width_m": {
      "value": 0.022,
      "source": "design",
      "basis": "whole-chain reach, root-to-tip taper and local span; explicit dimensions take precedence"
    },
    "thickness_m": {
      "value": 0.018039999999999997,
      "source": "estimated",
      "basis": "whole-chain reach, root-to-tip taper and local span; explicit dimensions take precedence"
    },
    "diameter_m": {
      "value": 0.0297,
      "source": "estimated",
      "basis": "whole-chain reach, root-to-tip taper and local span; explicit dimensions take precedence"
    },
    "module_space_cap_m": {
      "value": 0.042300000000000004,
      "source": "estimated",
      "basis": "90% of nearest nonzero installation spacing across coincident frames"
    },
    "axial_width_m": {
      "value": 0.018039999999999997,
      "source": "estimated",
      "basis": "whole-chain reach, root-to-tip taper and local span; explicit dimensions take precedence"
    },
    "template": "elbow_shell",
    "distal_setback_m": {
      "value": 0.01,
      "source": "design",
      "basis": "whole-chain reach, root-to-tip taper and local span; explicit dimensions take precedence"
    },
    "shell_collision": "central box; rounded end transitions approximated by joint housings, not exact surface collision"
  },
  "mass": {
    "mass_kg": 0.21200000000000002,
    "com_m": [
      0.0,
      0.0,
      -0.005542452830188679
    ],
    "inertia_kg_m2": [
      [
        3.3093692857861636e-05,
        0.0,
        0.0
      ],
      [
        0.0,
        3.589489125786164e-05,
        0.0
      ],
      [
        0.0,
        0.0,
        1.4300134933333331e-05
      ]
    ],
    "sources": [
      "link: known mass distributed on documented proxy translated to supplied COM",
      "joint_output_equivalent: known mass distributed on documented proxy translated to supplied COM"
    ]
  },
  "mass_proxy": {
    "kind": "box",
    "size": [
      0.022,
      0.018039999999999997,
      0.0188
    ],
    "T": [
      [
        -1.0,
        0.0,
        0.0,
        0.0
      ],
      [
        0.0,
        1.0,
        0.0,
        0.0
      ],
      [
        0.0,
        0.0,
        -1.0,
        -0.0235
      ],
      [
        0.0,
        0.0,
        0.0,
        1.0
      ]
    ]
  }
}
```

### J7_link

rounded-shell-v2: whole-arm shell and tool_wrist

```json
{
  "dimensions": {
    "width_m": {
      "value": 0.030226000000000013,
      "source": "estimated",
      "basis": "whole-chain reach, root-to-tip taper and local span; explicit dimensions take precedence"
    },
    "thickness_m": {
      "value": 0.02478532000000001,
      "source": "estimated",
      "basis": "whole-chain reach, root-to-tip taper and local span; explicit dimensions take precedence"
    },
    "diameter_m": {
      "value": 0.036000000000000004,
      "source": "estimated",
      "basis": "whole-chain reach, root-to-tip taper and local span; explicit dimensions take precedence"
    },
    "module_space_cap_m": {
      "value": 0.036000000000000004,
      "source": "estimated",
      "basis": "90% of nearest nonzero installation spacing across coincident frames"
    },
    "axial_width_m": {
      "value": 0.02478532000000001,
      "source": "estimated",
      "basis": "whole-chain reach, root-to-tip taper and local span; explicit dimensions take precedence"
    },
    "template": "tool_wrist",
    "shell_collision": "central box; rounded end transitions approximated by joint housings, not exact surface collision",
    "flange": {
      "diameter_m": {
        "value": 0.03173730000000002,
        "source": "estimated",
        "basis": "whole-chain reach, root-to-tip taper and local span; explicit dimensions take precedence"
      },
      "axial_width_m": {
        "value": 0.005440680000000002,
        "source": "estimated",
        "basis": "whole-chain reach, root-to-tip taper and local span; explicit dimensions take precedence"
      }
    }
  },
  "mass": {
    "mass_kg": 0.21200000000000002,
    "com_m": [
      0.0,
      0.0,
      -0.0047169811320754715
    ],
    "inertia_kg_m2": [
      [
        3.594614787725788e-05,
        0.0,
        0.0
      ],
      [
        0.0,
        3.065853241380027e-05,
        0.0
      ],
      [
        0.0,
        0.0,
        2.6993309221875757e-05
      ]
    ],
    "sources": [
      "link: known mass distributed on documented proxy translated to supplied COM",
      "joint_output_equivalent: known mass distributed on documented proxy translated to supplied COM"
    ]
  },
  "mass_proxy": {
    "kind": "box",
    "size": [
      0.030226000000000013,
      0.02478532000000001,
      0.016
    ],
    "T": [
      [
        -0.0,
        1.0,
        0.0,
        0.0
      ],
      [
        1.0,
        0.0,
        0.0,
        0.0
      ],
      [
        0.0,
        0.0,
        -1.0,
        -0.02
      ],
      [
        0.0,
        0.0,
        0.0,
        1.0
      ]
    ]
  }
}
```

## 验证边界

Mesh 检查闭合、面朝向、退化面。碰撞为低复杂度盒体/圆柱；干涉筛查为保守 AABB，候选不等于已证实穿透，无候选也不证明整个关节范围无碰撞。
当前报告 50 个包围盒相交候选；详见 validation.json。

独立 URDF 的相对资源根目录必须设为 URDF 所在目录（或加载前将相对文件名解析到此目录）；验证器复制整个目录后重新解析与加载 STL。安装在 world_fixed 中；加载器不得再施加同一安装变换。

MuJoCo 使用导出目录中的 run.py 启动，自动加载 initial keyframe；自定义加载时调用 mj_resetDataKeyframe(model,data,0)，同时恢复 q、ctrl 和滤波状态。USD robot.usd 以初始姿态装配，引用 robot_zero.usd 保存原始零位框架；两层一起搬移。在 Isaac 中使用 runtime_config.json 的建议物理步长，并以 SI 核对初始关节位置与目标。USD 旋转限位和驱动目标使用 deg，角驱动增益由每 rad 转为每 deg。

硬件额定值、控制器参数和静力学保持载荷分别保存；静力学 drives 不当作动态 effort/velocity。

## ROS1 Noetic 使用

将 ros1/*_description 复制到 catkin_ws/src，安装 robot_state_publisher、joint_state_publisher、joint_state_publisher_gui、rviz；执行：

```bash
cd ~/catkin_ws
catkin_make
source devel/setup.bash
roslaunch worksheet_reference_description display.launch
roslaunch worksheet_reference_description display.launch gui:=false
```

运行后检查 RobotModel 无资源/TF 错误，滑块逐关节方向、上下限和初始值正确。ROS1/RViz 和 Isaac 未运行时必须保留 pending。

## Isaac 导入与待执行验证

若安装了指定版本 Isaac Sim，优先用该版本官方 URDF Importer；Fix Base=True、Merge Fixed Joints=False、导入惯量=True、碰撞使用 URDF primitive、保留命名与 tool_frame。以 report/normalized_model.json 核对轴与限位。不要对已含 world_fixed 的描述再次应用安装位姿。

本次 robot.usd 由 OpenUSD 离线生成（如该目标成功）；这不代表 Isaac articulation/PhysX 步进已通过。使用同目录 runtime_config.json 及 Skill scripts/isaac_runtime.py 进行实机验收。
