# 模型生成报告

模型：franka_fr3_reference；等级：supplied_physics_unverified。

所有坐标为右手系，m/kg/rad；RPY=Rz Ry Rx。基座安装只应用于 world→base 一次。几何零位与初始关节值分开保存。

| 目标 | 生成/检查状态 | 运行时 |
|---|---|---|
| urdf | static_checked | pending |
| mujoco | failed | passed |

零件级碰撞复核：failed。姿态覆盖、零件配合和接触面偏差见 [validation.json](validation.json) 的 collision_review。
优先检查 fr3_link5/fr3_joint6_support / fr3_link6/beam，姿态 fr3_joint6_upper。

[机械臂初始姿态预览](../preview.png)

## 外形生成

规则：rounded-shell-v2。整链比例、肩肘腕模组空间约束、多截面连续外壳、圆肩端盖和分区材质；使用 NumPy 原生生成，没有 CAD 依赖。

外壳模板是概念设计推定；每个实体部件闭合，但同一连杆的壳体/端盖可局部相交，未执行 CAD 布尔融合。碰撞使用中央梁盒体与模组圆柱近似，圆滑过渡不等同于精确接触表面。实体重叠不重复计重。详细规则、尺寸与模板见 appearance_design.json 和下方逐连杆记录。


## 关节模组布置

规则：axis-module-layout-v1；状态：resolved。原始运动学帧保持不变，自转固定壳归上游连杆、输出套筒归下游连杆，模组退让不移动已有质量/质心。

| 组合 | 模板 | 自转退让 m | 摆动侧置 m |
|---|---|---:|---:|
| fr3_joint1 / fr3_joint2 | twist_bend | 0.14 | 0.0823928 |
| fr3_joint5 / fr3_joint6 | twist_bend | 0.1 | 0.03972 |

独立模组包络检查：passed。该检查不受仿真碰撞过滤影响，详见 validation.json/module_packing；不等同于全机构可制造性证明。


## 缺项与假设

- Concept outer shells retain official rigid-body masses, COM, inertias, and all reference kinematic frames. Distal beam setbacks provide elbow and wrist clearance.
- fr3_joint2: sampled static deflection exceeds design target; effort budget/given gains retained
- fr3_joint3: sampled static deflection exceeds design target; effort budget/given gains retained
- fr3_joint4: sampled static deflection exceeds design target; effort budget/given gains retained

## 驱动参数

策略：serial-pd-v1；状态：resolved；建议物理步长：0.000739783 s。

SI 参数供 MJCF / USD 共用。角 kp 单位 Nm/rad、kv 单位 Nm·s/rad；移动轴为 N/m、N·s/m。USD 角增益另按每度换算。固定规则和采样证据见 drive_design.json；没有伪造质量、转子惯量、摩擦或重力补偿。

| 关节 | 模式 | kp | kv | 力/矩上限 | 来源 kp / kv |
|---|---|---:|---:|---:|---|
| fr3_joint1 | position | 164.73467 | 65.461943 | 87 | automatic / automatic |
| fr3_joint2 | position | 435 | 133.93551 | 87 | automatic / automatic |
| fr3_joint3 | position | 435 | 84.605859 | 87 | automatic / automatic |
| fr3_joint4 | position | 435 | 70.208533 | 87 | automatic / automatic |
| fr3_joint5 | position | 49.434595 | 5.1224449 | 12 | automatic / automatic |
| fr3_joint6 | position | 52.090617 | 4.9391192 | 12 | automatic / automatic |
| fr3_joint7 | position | 2.2015585 | 0.38937266 | 12 | automatic / automatic |

MuJoCo 位置驱动验收：passed。以下仅为接触开启的有限姿态结果；静差单独报告，不以稳定代替精度。

| 工况 | 稳定 | 最大尾段峰峰值 | 最大尾段速度 | 最大静差 |
|---|---|---:|---:|---:|
| hold_initial | True | 3.39753e-07 | 1.34333e-06 | 0.038878 |
| hold_offset | True | 4.78414e-07 | 1.89154e-06 | 0.0391124 |
| smooth_move | True | 1.37687e-06 | 4.90736e-06 | 0.0389548 |

数值分别使用 rad/m、rad/s或m/s；混合关节的逐轴数值和饱和率详见 validation.json。

## 装配配合体碰撞排除

两种仿真格式共用以下拓扑排除，避免相邻配合壳体互相顶开。共点壳体扩展只跨零平移 revolute/fixed 链，遇移动轴或非零偏移即停止；不自动排除其他穿插。真实 CAD 需另行复核。

- fr3_link0 / fr3_link1：direct joint mating pair
- fr3_link0 / fr3_link2：coincident revolute/fixed installation cluster
- fr3_link1 / fr3_link2：direct joint mating pair
- fr3_link2 / fr3_link3：direct joint mating pair
- fr3_link3 / fr3_link4：direct joint mating pair
- fr3_link4 / fr3_link5：direct joint mating pair
- fr3_link4 / fr3_link6：coincident revolute/fixed installation cluster
- fr3_link5 / fr3_link6：direct joint mating pair
- fr3_link6 / fr3_link7：direct joint mating pair

## 连杆生成与质量来源

### fr3_link0

rounded-shell-v2: whole-arm shell and pedestal

```json
{
  "dimensions": {
    "width_m": {
      "value": 0.1,
      "source": "estimated",
      "basis": "whole-chain reach, root-to-tip taper and local span; explicit dimensions take precedence"
    },
    "thickness_m": {
      "value": 0.082,
      "source": "estimated",
      "basis": "whole-chain reach, root-to-tip taper and local span; explicit dimensions take precedence"
    },
    "diameter_m": {
      "value": 0.18225000000000002,
      "source": "estimated",
      "basis": "whole-chain reach, root-to-tip taper and local span; explicit dimensions take precedence"
    },
    "module_space_cap_m": {
      "value": 0.2997,
      "source": "estimated",
      "basis": "90% of nearest nonzero installation spacing across coincident frames"
    },
    "axial_width_m": {
      "value": 0.082,
      "source": "estimated",
      "basis": "whole-chain reach, root-to-tip taper and local span; explicit dimensions take precedence"
    },
    "template": "pedestal",
    "shell_collision": "central box; rounded end transitions approximated by joint housings, not exact surface collision",
    "assembly_shell_endpoint_m": [
      0.0,
      0.0,
      0.15
    ]
  },
  "mass": {
    "mass_kg": 0.629769,
    "com_m": [
      -0.041018,
      -0.00014,
      0.049974
    ],
    "inertia_kg_m2": [
      [
        0.00315,
        8.2904e-07,
        0.00015
      ],
      [
        8.2904e-07,
        0.00388,
        8.2299e-06
      ],
      [
        0.00015,
        8.2299e-06,
        0.004285
      ]
    ],
    "sources": [
      "rigid_body: supplied mass/COM/inertia"
    ]
  },
  "mass_proxy": {
    "kind": "box",
    "size": [
      0.1,
      0.082,
      0.1332
    ],
    "T": [
      [
        0.0,
        1.0,
        0.0,
        0.0
      ],
      [
        -1.0,
        0.0,
        0.0,
        0.0
      ],
      [
        0.0,
        0.0,
        1.0,
        0.1665
      ],
      [
        0.0,
        0.0,
        0.0,
        1.0
      ]
    ]
  }
}
```

### fr3_link1

rounded-shell-v2: whole-arm shell and axial_output_sleeve

```json
{
  "dimensions": {
    "width_m": {
      "value": 0.1,
      "source": "estimated",
      "basis": "whole-chain reach, root-to-tip taper and local span; explicit dimensions take precedence"
    },
    "thickness_m": {
      "value": 0.082,
      "source": "estimated",
      "basis": "whole-chain reach, root-to-tip taper and local span; explicit dimensions take precedence"
    },
    "diameter_m": {
      "value": 0.135,
      "source": "estimated",
      "basis": "whole-chain reach, root-to-tip taper and local span; explicit dimensions take precedence"
    },
    "module_space_cap_m": {
      "value": 0.2844,
      "source": "estimated",
      "basis": "90% of nearest nonzero installation spacing across coincident frames"
    },
    "axial_width_m": {
      "value": 0.082,
      "source": "estimated",
      "basis": "whole-chain reach, root-to-tip taper and local span; explicit dimensions take precedence"
    },
    "template": "axial_output_sleeve",
    "short_span": {
      "value": 0.0,
      "source": "kinematics",
      "basis": "full-scale wrist housing; original frames preserved"
    }
  },
  "mass": {
    "mass_kg": 4.970684,
    "com_m": [
      0.003875,
      0.002081,
      -0.04762
    ],
    "inertia_kg_m2": [
      [
        0.70337,
        -0.000139,
        0.006772
      ],
      [
        -0.000139,
        0.70661,
        0.019169
      ],
      [
        0.006772,
        0.019169,
        0.009117
      ]
    ],
    "sources": [
      "rigid_body: supplied mass/COM/inertia"
    ]
  },
  "mass_proxy": {
    "kind": "cylinder",
    "size": [
      0.0675,
      0.082
    ],
    "T": [
      [
        0.0,
        1.0,
        0.0,
        0.0
      ],
      [
        -1.0,
        0.0,
        0.0,
        0.0
      ],
      [
        0.0,
        -0.0,
        1.0,
        0.0
      ],
      [
        0.0,
        0.0,
        0.0,
        1.0
      ]
    ]
  }
}
```

### fr3_link2

rounded-shell-v2: whole-arm shell and transverse_output

```json
{
  "dimensions": {
    "width_m": {
      "value": 0.09804003792550328,
      "source": "estimated",
      "basis": "whole-chain reach, root-to-tip taper and local span; explicit dimensions take precedence"
    },
    "thickness_m": {
      "value": 0.08039283109891268,
      "source": "estimated",
      "basis": "whole-chain reach, root-to-tip taper and local span; explicit dimensions take precedence"
    },
    "diameter_m": {
      "value": 0.13235405119942945,
      "source": "estimated",
      "basis": "whole-chain reach, root-to-tip taper and local span; explicit dimensions take precedence"
    },
    "module_space_cap_m": {
      "value": 0.2844,
      "source": "estimated",
      "basis": "90% of nearest nonzero installation spacing across coincident frames"
    },
    "axial_width_m": {
      "value": 0.08039283109891268,
      "source": "estimated",
      "basis": "whole-chain reach, root-to-tip taper and local span; explicit dimensions take precedence"
    },
    "template": "transverse_output",
    "shell_collision": "central box; rounded end transitions approximated by joint housings, not exact surface collision"
  },
  "mass": {
    "mass_kg": 0.646926,
    "com_m": [
      -0.003141,
      -0.028719999999999996,
      0.0034949999999999994
    ],
    "inertia_kg_m2": [
      [
        0.007962,
        -0.003925,
        0.010254
      ],
      [
        -0.003925,
        0.02811,
        0.000704
      ],
      [
        0.010254,
        0.000704,
        0.025995
      ]
    ],
    "sources": [
      "rigid_body: supplied mass/COM/inertia"
    ]
  },
  "mass_proxy": {
    "kind": "box",
    "size": [
      0.09804003792550328,
      0.08039283109891268,
      0.1704105436806276
    ],
    "T": [
      [
        1.0,
        0.0,
        0.0,
        0.0
      ],
      [
        0.0,
        0.0,
        -1.0,
        -0.158
      ],
      [
        -0.0,
        1.0,
        0.0,
        0.0
      ],
      [
        0.0,
        0.0,
        0.0,
        1.0
      ]
    ]
  }
}
```

### fr3_link3

rounded-shell-v2: whole-arm shell and elbow_shell

```json
{
  "dimensions": {
    "width_m": {
      "value": 0.054,
      "source": "design",
      "basis": "whole-chain reach, root-to-tip taper and local span; explicit dimensions take precedence"
    },
    "thickness_m": {
      "value": 0.04428,
      "source": "estimated",
      "basis": "whole-chain reach, root-to-tip taper and local span; explicit dimensions take precedence"
    },
    "diameter_m": {
      "value": 0.0729,
      "source": "estimated",
      "basis": "whole-chain reach, root-to-tip taper and local span; explicit dimensions take precedence"
    },
    "module_space_cap_m": {
      "value": 0.07425000000000001,
      "source": "estimated",
      "basis": "90% of nearest nonzero installation spacing across coincident frames"
    },
    "axial_width_m": {
      "value": 0.04428,
      "source": "estimated",
      "basis": "whole-chain reach, root-to-tip taper and local span; explicit dimensions take precedence"
    },
    "template": "elbow_shell",
    "distal_setback_m": {
      "value": 0.018,
      "source": "design",
      "basis": "whole-chain reach, root-to-tip taper and local span; explicit dimensions take precedence"
    },
    "shell_collision": "central box; rounded end transitions approximated by joint housings, not exact surface collision"
  },
  "mass": {
    "mass_kg": 3.228604,
    "com_m": [
      0.027518,
      0.03925200000000001,
      -0.066502
    ],
    "inertia_kg_m2": [
      [
        0.037242,
        -0.004761,
        -0.011396
      ],
      [
        -0.004761,
        0.036155,
        -0.012805
      ],
      [
        -0.011396,
        -0.012805,
        0.01083
      ]
    ],
    "sources": [
      "rigid_body: supplied mass/COM/inertia"
    ]
  },
  "mass_proxy": {
    "kind": "box",
    "size": [
      0.054,
      0.04428,
      0.033
    ],
    "T": [
      [
        0.0,
        0.0,
        1.0,
        0.04125
      ],
      [
        1.0,
        0.0,
        0.0,
        0.0
      ],
      [
        0.0,
        1.0,
        0.0,
        0.0
      ],
      [
        0.0,
        0.0,
        0.0,
        1.0
      ]
    ]
  }
}
```

### fr3_link4

rounded-shell-v2: whole-arm shell and elbow_shell

```json
{
  "dimensions": {
    "width_m": {
      "value": 0.08394277757020215,
      "source": "estimated",
      "basis": "whole-chain reach, root-to-tip taper and local span; explicit dimensions take precedence"
    },
    "thickness_m": {
      "value": 0.06883307760756575,
      "source": "estimated",
      "basis": "whole-chain reach, root-to-tip taper and local span; explicit dimensions take precedence"
    },
    "diameter_m": {
      "value": 0.07425000000000001,
      "source": "estimated",
      "basis": "whole-chain reach, root-to-tip taper and local span; explicit dimensions take precedence"
    },
    "module_space_cap_m": {
      "value": 0.07425000000000001,
      "source": "estimated",
      "basis": "90% of nearest nonzero installation spacing across coincident frames"
    },
    "axial_width_m": {
      "value": 0.05346000000000001,
      "source": "estimated",
      "basis": "whole-chain reach, root-to-tip taper and local span; explicit dimensions take precedence"
    },
    "template": "elbow_shell",
    "shell_collision": "central box; rounded end transitions approximated by joint housings, not exact surface collision",
    "assembly_shell_endpoint_m": [
      -0.0825,
      0.253488,
      -1.4489742738987845e-17
    ]
  },
  "mass": {
    "mass_kg": 3.587895,
    "com_m": [
      -0.05317,
      0.104419,
      0.027454
    ],
    "inertia_kg_m2": [
      [
        0.025853,
        0.007796,
        -0.001332
      ],
      [
        0.007796,
        0.019552,
        0.008641
      ],
      [
        -0.001332,
        0.008641,
        0.028323
      ]
    ],
    "sources": [
      "rigid_body: supplied mass/COM/inertia"
    ]
  },
  "mass_proxy": {
    "kind": "box",
    "size": [
      0.08394277757020215,
      0.06883307760756575,
      0.31108733271534583
    ],
    "T": [
      [
        -0.9776904962989506,
        0.0,
        -0.21005069256422768,
        -0.04125
      ],
      [
        -0.21005069256422768,
        0.0,
        0.9776904962989506,
        0.192
      ],
      [
        0.0,
        1.0,
        0.0,
        0.0
      ],
      [
        0.0,
        0.0,
        0.0,
        1.0
      ]
    ]
  }
}
```

### fr3_link5

rounded-shell-v2: whole-arm shell and axial_output_sleeve

```json
{
  "dimensions": {
    "width_m": {
      "value": 0.0768941473925516,
      "source": "estimated",
      "basis": "whole-chain reach, root-to-tip taper and local span; explicit dimensions take precedence"
    },
    "thickness_m": {
      "value": 0.06305320086189231,
      "source": "estimated",
      "basis": "whole-chain reach, root-to-tip taper and local span; explicit dimensions take precedence"
    },
    "diameter_m": {
      "value": 0.07919999999999999,
      "source": "estimated",
      "basis": "whole-chain reach, root-to-tip taper and local span; explicit dimensions take precedence"
    },
    "module_space_cap_m": {
      "value": 0.07919999999999999,
      "source": "estimated",
      "basis": "90% of nearest nonzero installation spacing across coincident frames"
    },
    "axial_width_m": {
      "value": 0.05702399999999999,
      "source": "estimated",
      "basis": "whole-chain reach, root-to-tip taper and local span; explicit dimensions take precedence"
    },
    "template": "axial_output_sleeve",
    "short_span": {
      "value": 0.0,
      "source": "kinematics",
      "basis": "full-scale wrist housing; original frames preserved"
    }
  },
  "mass": {
    "mass_kg": 1.225946,
    "com_m": [
      -0.011953,
      0.041065,
      -0.038437
    ],
    "inertia_kg_m2": [
      [
        0.035549,
        -0.002117,
        -0.004037
      ],
      [
        -0.002117,
        0.029474,
        0.000229
      ],
      [
        -0.004037,
        0.000229,
        0.008627
      ]
    ],
    "sources": [
      "rigid_body: supplied mass/COM/inertia"
    ]
  },
  "mass_proxy": {
    "kind": "cylinder",
    "size": [
      0.039599999999999996,
      0.05702399999999999
    ],
    "T": [
      [
        0.0,
        1.0,
        0.0,
        0.0
      ],
      [
        -1.0,
        0.0,
        0.0,
        0.0
      ],
      [
        0.0,
        -0.0,
        1.0,
        0.0
      ],
      [
        0.0,
        0.0,
        0.0,
        1.0
      ]
    ]
  }
}
```

### fr3_link6

rounded-shell-v2: whole-arm shell and transverse_output

```json
{
  "dimensions": {
    "width_m": {
      "value": 0.046,
      "source": "design",
      "basis": "whole-chain reach, root-to-tip taper and local span; explicit dimensions take precedence"
    },
    "thickness_m": {
      "value": 0.03772,
      "source": "estimated",
      "basis": "whole-chain reach, root-to-tip taper and local span; explicit dimensions take precedence"
    },
    "diameter_m": {
      "value": 0.0621,
      "source": "estimated",
      "basis": "whole-chain reach, root-to-tip taper and local span; explicit dimensions take precedence"
    },
    "module_space_cap_m": {
      "value": 0.07919999999999999,
      "source": "estimated",
      "basis": "90% of nearest nonzero installation spacing across coincident frames"
    },
    "axial_width_m": {
      "value": 0.03772,
      "source": "estimated",
      "basis": "whole-chain reach, root-to-tip taper and local span; explicit dimensions take precedence"
    },
    "template": "transverse_output",
    "distal_setback_m": {
      "value": 0.018,
      "source": "design",
      "basis": "whole-chain reach, root-to-tip taper and local span; explicit dimensions take precedence"
    },
    "shell_collision": "central box; rounded end transitions approximated by joint housings, not exact surface collision"
  },
  "mass": {
    "mass_kg": 1.666555,
    "com_m": [
      0.060149,
      -0.014117,
      -0.010517000000000002
    ],
    "inertia_kg_m2": [
      [
        0.001964,
        0.000109,
        -0.001158
      ],
      [
        0.000109,
        0.004354,
        0.000341
      ],
      [
        -0.001158,
        0.000341,
        0.005433
      ]
    ],
    "sources": [
      "rigid_body: supplied mass/COM/inertia"
    ]
  },
  "mass_proxy": {
    "kind": "box",
    "size": [
      0.046,
      0.03772,
      0.0352
    ],
    "T": [
      [
        0.0,
        0.0,
        1.0,
        0.044
      ],
      [
        1.0,
        0.0,
        0.0,
        0.0
      ],
      [
        0.0,
        1.0,
        0.0,
        0.0
      ],
      [
        0.0,
        0.0,
        0.0,
        1.0
      ]
    ]
  }
}
```

### fr3_link7

rounded-shell-v2: whole-arm shell and tool_wrist

```json
{
  "dimensions": {
    "width_m": {
      "value": 0.041,
      "source": "design",
      "basis": "whole-chain reach, root-to-tip taper and local span; explicit dimensions take precedence"
    },
    "thickness_m": {
      "value": 0.03362,
      "source": "estimated",
      "basis": "whole-chain reach, root-to-tip taper and local span; explicit dimensions take precedence"
    },
    "diameter_m": {
      "value": 0.05535,
      "source": "estimated",
      "basis": "whole-chain reach, root-to-tip taper and local span; explicit dimensions take precedence"
    },
    "module_space_cap_m": {
      "value": 0.07919999999999999,
      "source": "estimated",
      "basis": "90% of nearest nonzero installation spacing across coincident frames"
    },
    "axial_width_m": {
      "value": 0.03362,
      "source": "estimated",
      "basis": "whole-chain reach, root-to-tip taper and local span; explicit dimensions take precedence"
    },
    "template": "tool_wrist",
    "shell_collision": "central box; rounded end transitions approximated by joint housings, not exact surface collision",
    "flange": {
      "diameter_m": {
        "value": 0.043050000000000005,
        "source": "estimated",
        "basis": "whole-chain reach, root-to-tip taper and local span; explicit dimensions take precedence"
      },
      "axial_width_m": {
        "value": 0.00738,
        "source": "estimated",
        "basis": "whole-chain reach, root-to-tip taper and local span; explicit dimensions take precedence"
      }
    }
  },
  "mass": {
    "mass_kg": 0.735522,
    "com_m": [
      0.010517,
      -0.004252,
      0.06159699999999999
    ],
    "inertia_kg_m2": [
      [
        0.012516,
        -0.000428,
        -0.001196
      ],
      [
        -0.000428,
        0.010027,
        -0.000741
      ],
      [
        -0.001196,
        -0.000741,
        0.004815
      ]
    ],
    "sources": [
      "rigid_body: supplied mass/COM/inertia"
    ]
  },
  "mass_proxy": {
    "kind": "box",
    "size": [
      0.041,
      0.03362,
      0.04611499999999999
    ],
    "T": [
      [
        0.0,
        1.0,
        0.0,
        0.0
      ],
      [
        -1.0,
        0.0,
        0.0,
        0.0
      ],
      [
        0.0,
        0.0,
        1.0,
        0.0535
      ],
      [
        0.0,
        0.0,
        0.0,
        1.0
      ]
    ]
  }
}
```

## 验证边界

Mesh 检查闭合、面朝向、退化面。碰撞为低复杂度盒体/圆柱；干涉筛查为保守 AABB，候选不等于已证实穿透，无候选也不证明整个关节范围无碰撞。
当前报告 69 个包围盒相交候选；详见 validation.json。

独立 URDF 的相对资源根目录必须设为 URDF 所在目录（或加载前将相对文件名解析到此目录）；验证器复制整个目录后重新解析与加载 STL。安装在 world_fixed 中；加载器不得再施加同一安装变换。

MuJoCo 使用导出目录中的 run.py 启动，自动加载 initial keyframe；自定义加载时调用 mj_resetDataKeyframe(model,data,0)，同时恢复 q、ctrl 和滤波状态。USD robot.usd 以初始姿态装配，引用 robot_zero.usd 保存原始零位框架；两层一起搬移。在 Isaac 中使用 runtime_config.json 的建议物理步长，并以 SI 核对初始关节位置与目标。USD 旋转限位和驱动目标使用 deg，角驱动增益由每 rad 转为每 deg。

硬件额定值、控制器参数和静力学保持载荷分别保存；静力学 drives 不当作动态 effort/velocity。

## ROS1 Noetic 使用

将 ros1/*_description 复制到 catkin_ws/src，安装 robot_state_publisher、joint_state_publisher、joint_state_publisher_gui、rviz；执行：

```bash
cd ~/catkin_ws
catkin_make
source devel/setup.bash
roslaunch franka_fr3_reference_description display.launch
roslaunch franka_fr3_reference_description display.launch gui:=false
```

运行后检查 RobotModel 无资源/TF 错误，滑块逐关节方向、上下限和初始值正确。ROS1/RViz 和 Isaac 未运行时必须保留 pending。

## Isaac 导入与待执行验证

若安装了指定版本 Isaac Sim，优先用该版本官方 URDF Importer；Fix Base=True、Merge Fixed Joints=False、导入惯量=True、碰撞使用 URDF primitive、保留命名与 tool_frame。以 report/normalized_model.json 核对轴与限位。不要对已含 world_fixed 的描述再次应用安装位姿。

本次 robot.usd 由 OpenUSD 离线生成（如该目标成功）；这不代表 Isaac articulation/PhysX 步进已通过。使用同目录 runtime_config.json 及 Skill scripts/isaac_runtime.py 进行实机验收。
