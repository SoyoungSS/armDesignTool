# Copyright 2026 DeepMind Technologies Limited
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""Python web server for the MuJoCo Web Viewer.

This server runs on a background daemon thread with one asyncio loop on a single
public port:

  * Plain HTTP GET   serves static files (index.html, WASM, assets), /model,
                     and cached model bundles by content hash
                     (/model?crc32=...), which browsers prefetch and cache.
  * WebSocket /ui    streams the headless Studio UI to the controlling browser
                     and its input back, one Studio UI wire command per
                     WebSocket message and one frame in flight (see UiSession
                     and _UI_ACK_PREFIX).
  * WebSocket /state serves the latest-wins state payload broadcast at ~60Hz
                     (see state_payload.h) as binary frames, and session roster
                     and model prefetch updates as text frames.
  * WebSocket /drop  receives models dragged onto the page (one binary frame per
                     file, controller only; see drop_handler).

Because everything is served through one port, one firewall rule, port-forward,
or HTTPS tunnel exposes the whole viewer. The browser derives its WebSocket URLs
from the page origin so no client configuration is needed.

One browser at a time controls the interactive session (it owns the /ui
stream); later browsers are rejected from /ui with WebSocket close code
_WS_CLOSE_CONTROLLER_TAKEN and can take the controller slot once it frees up.
/state connections beyond the spectator limit are closed with close code
_WS_CLOSE_SESSION_FULL.
"""

import asyncio
import collections
import datetime
import enum
import functools
import importlib
import json
import logging
import os
import pathlib
import queue
import socket
import struct
import sys
import threading
from typing import Any, Awaitable, Callable, Protocol
import urllib.parse
import zlib

from websockets.asyncio.server import serve
from websockets.asyncio.server import ServerConnection
from websockets.datastructures import Headers
from websockets.exceptions import ConnectionClosed
from websockets.exceptions import InvalidHandshake
from websockets.frames import CloseCode
from websockets.http11 import Request
from websockets.http11 import Response

# Our custom WebSocket close codes in range 4xxx. The client shows a notice
# and retries slowly (see web_client_session.cc / web_client.cc).
_WS_CLOSE_CONTROLLER_TAKEN = 4001  # /ui:    another browser is controlling.
_WS_CLOSE_SESSION_FULL = 4002  # /state: the spectator limit is reached.
_WS_CLOSE_INACTIVE = 4003  # /state: hidden tab kicked to free a slot.
_WS_CLOSE_NOT_CONTROLLER = 4004  # /drop: only the controller may load models.
_WS_CLOSE_VIEWER_ERROR = 4005  # /state: the viewer stopped with an error.

# A WebSocket close frame carries at most 123 bytes of reason text.
_WS_CLOSE_REASON_MAX_BYTES = 123

# Upper bound on the runtime-editable spectator limit.
_MAX_SPECTATOR_HARD_CAP = 32

# How many browsers may watch in addition to the controller; the controller can
# change it at runtime (up to _MAX_SPECTATOR_HARD_CAP). The limit is about
# session behaviour — keeping the crowd and the control-request queue at a
# manageable size — not about resources: a state payload is a few KB at
# 60Hz, serialized once and sent per viewer, so even a full session costs
# only a few Mbit/s of upload. There is deliberately no config or CLI
# option (spectating exposes nothing that controlling does not).
_MAX_SPECTATORS_DEFAULT = 8

# Controller-only message prefix carrying the new spectator limit.
_MAX_SPECTATORS_PREFIX = "max_spectators="
# Controller-only message prefix carrying the UI theme ("light", "dark", ...).
_THEME_PREFIX = "theme="
# Sent to the page whose control claim the controller slot is reserved for.
_GRANT_MESSAGE = "grant"
# Sent by the browser after applying each state payload (keep in sync:
# web_client_session.cc). Flow control for the /state stream: at most
# _STATE_MAX_IN_FLIGHT payloads are in flight per client, so a slow link
# carries the freshest state it can instead of buffering seconds of stale
# payloads in the socket, while links with non-zero round-trip latency
# (~20-50ms over reverse proxies) keep streaming smoothly at 60Hz.
_STATE_ACK_MESSAGE = "state_ack"
# Sent to every browser when it joins and whenever its list of cached model
# bundles changes: "prefetch=<crc32>:<bytes>,<crc32>:<bytes>,..." in the order
# to download them in (see WebServer.prefetch_line); a bare "prefetch=" means
# there is nothing left to prefetch. Each bundle is fetched as
# /model?crc32=<crc32> (see _serve_model).
_PREFETCH_PREFIX = "prefetch="

_THEMES = ("light", "dark", "classic")

# Maximum unacknowledged /state payloads in flight per client before
# send_payloads() waits for an ack and coalesces intermediate updates.
# An 8-frame window keeps 60-240 FPS streaming across proxy RTTs without
# letting slow connections build up multi-second queues.
_STATE_MAX_IN_FLIGHT = 8

# Sent by the browser on /ui after it receives draw frames, followed by the
# index of the newest: the same flow control for the UI stream, which keeps at
# most one frame in flight. The index tells the ack of the frame in flight from
# a late ack of an older one, which must not release the next frame.
_UI_ACK_PREFIX = "ui_ack="

# A lost ack must not stall a stream forever; after this long the next payload
# is sent unacked, and so is the next UI frame if the page still sends input
# (see ui_handler).
_ACK_TIMEOUT_SEC = 2.0

# How many bytes of model bundles the server keeps for /model?crc32=... (the
# current model always counts, and is never evicted). Plenty for a playlist of
# scenes; a browser that asks for an evicted bundle falls back to /model.
_MODEL_CACHE_BYTES_DEFAULT = 512 * 1024 * 1024

# A control grant must arrive within this window, else it moves down the queue.
_GRANT_EXPIRY_SEC = 5.0

# A /ui client must complete its Hello handshake within this window.
_HANDSHAKE_TIMEOUT_SEC = 5.0


# A controller whose tab stops running (hidden or closed without a clean
# disconnect) is released once someone is waiting for control. Detected by
# silence: a live controller tab sends input packets every frame.
_CONTROLLER_SILENT_KICK_SEC = 90.0

# Spectators are kicked after this much heartbeat silence (their tab is hidden
# or gone), freeing a viewer slot. Live tabs heartbeat every ~30s.
_SPECTATOR_SILENT_KICK_SEC = 300.0

# Default public port, and how many consecutive ports to try when it is taken
# (e.g. by another running viewer).
_DEFAULT_HTTP_PORT = 8080
_PORT_SCAN_COUNT = 20

# Content types for the static files the HTTP handler serves.
_CONTENT_TYPES = {
    ".html": "text/html; charset=utf-8",
    ".js": "text/javascript",
    ".wasm": "application/wasm",
    ".data": "application/octet-stream",
    ".json": "application/json",
    ".png": "image/png",
    ".ico": "image/x-icon",
}


class _SessionMessage(enum.StrEnum):
  """Text messages browsers send on /state."""

  REQUEST_CONTROL = "request_control"
  LEAVE_QUEUE = "leave_queue"
  FORCE_CONTROL = "force_control"
  HEARTBEAT = "heartbeat"


class UiSession(Protocol):
  """The headless UI as the /ui stream sees it (headless_ui.HeadlessUi).

  The UI streams to one browser at a time, the controller. A session lasts while
  that browser is connected: it starts with the browser's handshake, and its
  first messages re-send everything the browser needs to draw the UI. Every
  message is one Studio UI wire command, sent as one binary WebSocket message.

  The server thread calls these; the viewer thread runs the UI frames.
  """

  def start_session(self, handshake: bytes) -> bytes:
    """Starts a session and returns the reply to the browser's handshake.

    Args:
      handshake: The browser's first /ui message (Hello handshake).

    Raises:
      ValueError: The browser cannot talk to this viewer.
    """
    ...

  def end_session(self) -> None:
    """Ends the session; frames are no longer recorded for the browser."""
    ...

  def push_input(self, message: bytes) -> bool:
    """Queues browser input for the next frame; False if it is not input."""
    ...

  def take_messages(self) -> list[bytes]:
    """Returns the messages to send to the browser now, possibly none.

    A non-empty list ends with one draw frame, after any texture changes; the
    browser acks it by its index (see last_frame_index and _UI_ACK_PREFIX).
    """
    ...

  def last_frame_index(self) -> int:
    """Returns the index of the last draw frame take_messages() returned."""
    ...


def _roster_line(
    viewers: int,
    role: str,
    queue_pos: int,
    queue_len: int,
    max_spectators: int,
) -> str:
  """Builds a roster line, the membership broadcast every browser receives.

  The roster is sent as a text frame on /state whenever the session changes (a
  viewer joins or leaves, queues for control, or control moves). It tells each
  browser how many viewers are connected, which role the server has currently
  assigned it, and where it stands in the control queue.

  Args:
    viewers: The number of viewers connected to the server.
    role: The browser's role ("controller", "spectator", or "none" when no
      browser holds the controller slot).
    queue_pos: The browser's position in the control queue (0 if not queued).
    queue_len: The number of browsers in the queue.
    max_spectators: The maximum number of spectators allowed.

  Returns:
    A string representing the roster line.
  """
  return (
      f"viewers={viewers};role={role};queue_pos={queue_pos};"
      f"queue_len={queue_len};max_spectators={max_spectators}"
  )


class _WebServerFormatter(logging.Formatter):

  def format(self, record: logging.LogRecord) -> str:
    level_char = record.levelname[0]
    dt = datetime.datetime.fromtimestamp(record.created)
    date_str = dt.strftime("%m%d")
    time_str = dt.strftime("%H:%M:%S.%f")
    filename = os.path.basename(record.pathname)
    line = record.lineno
    msg = record.getMessage()
    return f"{level_char}{date_str} {time_str} {filename}:{line}] {msg}"


logger = logging.getLogger("WebServer")


class _HandshakeNoiseFilter(logging.Filter):
  """Removes handshake-failure logs from connections that simply went away.

  Handshake failure are produced by two routine cases:

  1. browsers speculatively open spare connections and close them unused
  2. a page reload on model change tears connections down mid-handshake.

  The websockets library logs each as an opening-handshake failure as at ERROR
  level with a full traceback. Raising the log level would hide real handshake
  errors too, hence a filter matching exactly these signatures.
  """

  def filter(self, record: logging.LogRecord) -> bool:
    if record.getMessage() != "opening handshake failed":
      return True
    exc = record.exc_info[1] if record.exc_info else None
    if exc is None:
      return True
    if isinstance(exc, (ConnectionClosed, InvalidHandshake, EOFError, OSError)):
      return False  # The connection died or sent non-WS HTTP; nothing wrong.
    return "did not receive a valid HTTP request" not in str(exc)


def _configure_logging() -> None:
  """Configures this module's logger and reins in the websockets library's.

  Called once at import time; a no-op if already configured (re-import).
  """
  if logger.handlers:
    return
  # Info is a curated, always-on channel (browser connect/disconnect);
  # connection plumbing is logged at DEBUG.
  logger.setLevel(logging.INFO)
  handler = logging.StreamHandler(sys.stdout)
  handler.setFormatter(_WebServerFormatter())
  logger.addHandler(handler)
  logger.propagate = False
  # The websockets library logs its own lifecycle chatter at INFO ("server
  # listening", "connection rejected (200 OK)" for every HTTP request); keep
  # it to warnings and errors.
  logging.getLogger("websockets").setLevel(logging.WARNING)
  # Filters do not inherit down the logger tree, so it must be attached to
  # "websockets.server" itself.
  logging.getLogger("websockets.server").addFilter(_HandshakeNoiseFilter())


_configure_logging()


def bind_public_socket(host: str, port: int = 0) -> socket.socket:
  """Binds (but does not listen on) the public HTTP listening socket.

  The socket is bound in the viewer thread up front so that bind conflicts
  surface here, synchronously, rather than inside the server thread.

  Args:
    host: Interface to bind. "::" (the default) binds a dual-stack socket that
      accepts both IPv6 and IPv4 connections, falling back to IPv4-only when the
      machine has no IPv6 support.
    port: A specific port, or 0 to take the first free port starting at
      _DEFAULT_HTTP_PORT (so several viewers can run side by side).

  Returns:
    The bound socket.

  Raises:
    RuntimeError: If the requested port (or every scanned port) is taken.
  """
  if host == "::":
    try:
      socket.socket(socket.AF_INET6, socket.SOCK_STREAM).close()
    except OSError:
      host = "0.0.0.0"
  family = socket.AF_INET6 if ":" in host else socket.AF_INET

  candidates = (
      [port]
      if port
      else range(_DEFAULT_HTTP_PORT, _DEFAULT_HTTP_PORT + _PORT_SCAN_COUNT)
  )
  for candidate in candidates:
    sock = socket.socket(family, socket.SOCK_STREAM)
    if os.name == "posix" and sys.platform != "cygwin":
      sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    else:
      # On Windows, SO_REUSEADDR allows binding onto an actively listening port
      # instead of failing with EADDRINUSE; SO_EXCLUSIVEADDRUSE prevents port
      # hijacking so the port scan advances across running viewer instances.
      exclusive_addr = getattr(socket, "SO_EXCLUSIVEADDRUSE", None)
      if exclusive_addr is not None:
        sock.setsockopt(socket.SOL_SOCKET, exclusive_addr, 1)
    if family == socket.AF_INET6:
      # Dual-stack: also accept IPv4 connections (as IPv4-mapped addresses).
      sock.setsockopt(socket.IPPROTO_IPV6, socket.IPV6_V6ONLY, 0)
    try:
      sock.bind((host, candidate))
      return sock
    except OSError:
      sock.close()
  if port:
    raise RuntimeError(
        f"Port {port} is already in use, is another web viewer running? "
        "Pass a different --port, or 0 to pick one automatically."
    )
  raise RuntimeError(
      f"Ports {_DEFAULT_HTTP_PORT}-{_DEFAULT_HTTP_PORT + _PORT_SCAN_COUNT - 1} "
      "are all in use, are that many web viewers running?"
  )


def _session_id(ws: ServerConnection) -> str:
  """The page's session id (?sid=...), tying its /ui and /state together."""
  path = ws.request.path if ws.request else ""
  query = path.split("?", 1)[1] if "?" in path else ""
  for part in query.split("&"):
    if part.startswith("sid="):
      sid = urllib.parse.unquote(part[4:])[:128]
      if sid:
        return sid
  return f"anon-{id(ws)}"


def _close_reason(text: str) -> str:
  """Fits text into a close frame's reason, cutting at a character boundary."""
  return text.encode()[:_WS_CLOSE_REASON_MAX_BYTES].decode(errors="ignore")


def _find_static_files_dir() -> str | None:
  """Locate the web viewer static files.

  Packaged installations serve the precompiled browser client from the
  `mujoco-studio-wasm` package (`mujoco_studio_wasm.DIST_DIR`), while local
  source/editable builds prefer a freshly built `dist/` next to this file.

  Development option: Set MUJOCO_WEB_VIEWER_DIST to serve from a different
  directory (e.g. a local Emscripten build tree). This allows rapid iteration
  on web_client changes without rebuilding and reinstalling the package.

  Returns:
    Path to the static files directory, or None if not found.

  Raises:
    RuntimeError: If `mujoco-studio-wasm` is installed with a version that does
      not match `mujoco-core`.
  """
  env_dir = os.environ.get("MUJOCO_WEB_VIEWER_DIST")
  if env_dir:
    if os.path.isdir(env_dir):
      return env_dir
    logger.warning(
        "[Http] MUJOCO_WEB_VIEWER_DIST is not a directory: %s", env_dir
    )

  raw_here = pathlib.Path(os.path.abspath(__file__))
  here = raw_here.resolve()
  if not any(
      part.lower() in ("site-packages", "dist-packages")
      for part in (*raw_here.parts, *here.parts)
  ):
    dist_dir = here.parent / "dist"
    if (dist_dir / "web_client.wasm").is_file():
      return str(dist_dir)

  try:
    studio_wasm = importlib.import_module("mujoco_studio_wasm")
  except ImportError:
    return None

  wasm_version = getattr(studio_wasm, "__version__", None)
  try:
    core_version = importlib.import_module("mujoco._version").__version__
  except ImportError:
    core_version = None
  if (
      wasm_version is not None
      and core_version is not None
      and wasm_version != core_version
  ):
    raise RuntimeError(
        "Version mismatch between 'mujoco-studio-wasm'"
        f" ({wasm_version}) and 'mujoco-core' ({core_version}). Please"
        " upgrade all MuJoCo packages together:\n"
        f"  pip install --upgrade 'mujoco-core=={core_version}'"
        f" 'mujoco-studio=={core_version}'"
        f" 'mujoco-studio-wasm=={core_version}'"
    )

  wasm_dist = getattr(studio_wasm, "DIST_DIR", None)
  if wasm_dist and os.path.isdir(wasm_dist):
    return str(wasm_dist)

  return None


def _run_cancellable(main_loop_func: Callable[[], Awaitable[None]]) -> None:
  """Runs an asyncio loop, logging unexpected errors."""
  try:
    asyncio.run(main_loop_func())
  except asyncio.CancelledError:
    pass
  except Exception as e:  # pylint: disable=broad-exception-caught
    func_name = getattr(main_loop_func, "__name__", "main_loop_func")
    logger.error("[%s] Unexpected error: %s", func_name, e, exc_info=True)


def _run_server(
    server: "WebServer",
    stop_event: threading.Event,
) -> None:
  """The server thread: HTTP + /ui + /state on one port, one event loop."""

  http_sock = server.http_sock
  static_dir = server.static_files_dir
  static_root = os.path.realpath(static_dir) if static_dir else None

  def _http_headers(
      content_type: str,
      content_length: int,
      cacheable: bool,
      immutable: bool = False,
  ) -> Headers:
    headers = Headers()
    headers["Content-Type"] = content_type
    headers["Content-Length"] = str(content_length)
    # The WASM is a pthread build: SharedArrayBuffer requires cross-origin
    # isolation on every response.
    headers["Cross-Origin-Opener-Policy"] = "same-origin"
    headers["Cross-Origin-Embedder-Policy"] = "require-corp"
    if not cacheable:
      headers["Access-Control-Allow-Origin"] = "*"
      headers["Cache-Control"] = "no-store"
    elif immutable:
      # A content-addressed resource never changes: let the browser keep it.
      headers["Access-Control-Allow-Origin"] = "*"
      headers["Cache-Control"] = "public, max-age=31536000, immutable"
    return headers

  def _serve_model(query_string: str) -> Response:
    """Builds the response for GET /model and its query forms.

    The current model, which changes on hot-swap and is never cached:

      GET /model                                 -> full bundle bytes
      GET /model?total_bytes                     -> {"total_bytes": <n>}
      GET /model?offset_bytes=X&size_bytes=Y     -> bytes [X, X+Y)

    A cached bundle by content hash (the crc32 stamped into state payloads),
    which the browser prefetches and caches, with the same three forms. Its
    bytes never change, so the response is marked immutable:

      GET /model?crc32=N[&total_bytes|&offset_bytes=X&size_bytes=Y]

    Args:
      query_string: The request's query string, possibly empty.

    Returns:
      The HTTP response.
    """
    # total_bytes is a bare flag: keep blank values so it survives parsing.
    params = urllib.parse.parse_qs(query_string, keep_blank_values=True)
    if "crc32" in params:
      try:
        mjb_data = server.cached_model(int(params["crc32"][0]))
      except (ValueError, TypeError):
        return Response(400, "Bad Request", Headers(), b"bad crc32\n")
      immutable = True
    else:
      mjb_data = server.mjb_data  # Snapshot to prevent race with update_model()
      immutable = False
    if not mjb_data:
      return Response(404, "Not Found", Headers(), b"no model\n")

    if "total_bytes" in params:
      body = json.dumps({"total_bytes": len(mjb_data)}).encode()
      headers = _http_headers(
          "application/json", len(body), cacheable=immutable, immutable=True
      )
      return Response(200, "OK", headers, body)
    if "offset_bytes" in params or "size_bytes" in params:
      try:
        offset = int(params.get("offset_bytes", [0])[0])
        size = int(params.get("size_bytes", [0])[0])
      except (ValueError, TypeError):
        return Response(400, "Bad Request", Headers(), b"bad params\n")
      if size <= 0 or offset < 0 or offset >= len(mjb_data):
        return Response(400, "Bad Request", Headers(), b"bad range\n")
      mjb_data = mjb_data[offset : min(offset + size, len(mjb_data))]
    headers = _http_headers(
        "application/octet-stream",
        len(mjb_data),
        cacheable=immutable,
        immutable=True,
    )
    return Response(200, "OK", headers, mjb_data)

  def _serve_http(path: str) -> Response:
    """Builds the HTTP response for a non-WebSocket GET request."""
    if path == "/model":
      return _serve_model("")

    if static_root is None:
      return Response(503, "Service Unavailable", Headers(), b"no dist dir\n")

    rel = path.lstrip("/") or "index.html"
    norm_static_root = os.path.normpath(static_root)
    full = os.path.normpath(os.path.join(norm_static_root, rel))
    if full != norm_static_root and not full.startswith(
        norm_static_root + os.sep
    ):
      return Response(403, "Forbidden", Headers(), b"forbidden\n")
    if not os.path.isfile(full):
      wasm_full = os.path.normpath(os.path.join(norm_static_root, "wasm", rel))
      studio_root = os.path.normpath(
          os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
      )
      studio_assets_full = os.path.normpath(os.path.join(studio_root, rel))
      if os.path.isfile(wasm_full):
        full = wasm_full
      elif (
          rel.startswith("assets/")
          and studio_assets_full.startswith(
              os.path.join(studio_root, "assets") + os.sep
          )
          and os.path.isfile(studio_assets_full)
      ):
        full = studio_assets_full
      else:
        return Response(404, "Not Found", Headers(), b"not found\n")

    with open(full, "rb") as f:
      body = f.read()
    content_type = _CONTENT_TYPES.get(
        os.path.splitext(full)[1], "application/octet-stream"
    )
    cacheable = not rel.endswith("index.html")
    return Response(
        200,
        "OK",
        _http_headers(content_type, len(body), cacheable=cacheable),
        body,
    )

  async def main_loop() -> None:
    # Wakes the /ui sender when the viewer thread has a new UI frame for the
    # browser (see WebServer.notify_ui_frame()).
    ui_frame_ready = asyncio.Event()
    server._wake_ui_stream = (  # pylint: disable=protected-access
        functools.partial(
            asyncio.get_running_loop().call_soon_threadsafe, ui_frame_ready.set
        )
    )

    # The browser controlling the UI (single slot), any /ui handshake currently
    # in flight, and all browsers receiving the state broadcast (controller +
    # spectators), keyed by session id.
    active_ui_ws: ServerConnection | None = None
    claiming_ui_ws: ServerConnection | None = None
    controller_sid: str | None = None
    state_clients: dict[str, ServerConnection] = {}

    # Wakes every /state stream when the viewer thread publishes a payload (see
    # WebServer.update_state), so a payload goes out the moment it exists. A
    # 60Hz poll instead would free-run against the viewer's 60Hz frame clock
    # and periodically cost a whole tick. One event per stream: each stream
    # clears its own, so a shared one would lose wakeups for the others.
    state_waiters: set[asyncio.Event] = set()

    def wake_state_streams() -> None:
      for event in state_waiters:
        event.set()

    server._wake_state_streams = functools.partial(
        asyncio.get_running_loop().call_soon_threadsafe, wake_state_streams
    )

    # Control handoff: spectators queue for the controller slot; when it frees,
    # the head of the queue is granted a short exclusive claim window.
    control_queue: list[str] = []
    pending_grant_sid: str | None = None
    broadcast_roster: Any = None
    grant_next: Any = None

    # Strong references to fire-and-forget tasks (the grant-expiry watchdog):
    # asyncio holds only a weak reference, so without this a task can be
    # garbage-collected mid-sleep and never run.
    background_tasks: set[asyncio.Task[Any]] = set()
    max_spectators = _MAX_SPECTATORS_DEFAULT

    # Liveness by absence of traffic: a hidden tab's rendering loop stops,
    # so it cannot report anything — silence is the signal.
    last_heartbeat: dict[str, float] = {}
    last_controller_input = [0.0]
    loop_time = asyncio.get_event_loop().time

    # Whether a browser the UI cannot talk to was logged (see ui_handler).
    ui_rejection_logged = False

    async def broadcast_roster() -> None:
      """Sends every browser the counts, its role and its queue position."""
      count = len(state_clients)
      for sid, client in list(state_clients.items()):
        if controller_sid is None:
          role = "none"
        elif sid == controller_sid:
          role = "controller"
        else:
          role = "spectator"
        try:
          pos = control_queue.index(sid) + 1
        except ValueError:
          pos = 0
        try:
          await client.send(
              _roster_line(
                  viewers=count,
                  role=role,
                  queue_pos=pos,
                  queue_len=len(control_queue),
                  max_spectators=max_spectators,
              )
          )
        except (ConnectionClosed, ConnectionError):
          pass

    async def grant_next() -> None:
      """Offers the free controller slot to the pending or next queued page."""
      nonlocal pending_grant_sid
      if active_ui_ws is not None or claiming_ui_ws is not None:
        return

      if pending_grant_sid is None:
        while control_queue:
          candidate = control_queue.pop(0)
          if candidate in state_clients:
            pending_grant_sid = candidate
            break
      if pending_grant_sid is None:
        return

      client = state_clients.get(pending_grant_sid)
      if client is None:
        pending_grant_sid = None
        await grant_next()
        return

      try:
        await client.send(_GRANT_MESSAGE)
      except (ConnectionClosed, ConnectionError):
        pending_grant_sid = None
        await grant_next()
        return
      logger.info("[Session] Control granted to %s", pending_grant_sid)
      await broadcast_roster()

      async def expire(granted: str) -> None:
        nonlocal pending_grant_sid
        await asyncio.sleep(_GRANT_EXPIRY_SEC)
        if (
            pending_grant_sid == granted
            and active_ui_ws is None
            and claiming_ui_ws is None
        ):
          pending_grant_sid = None
          await grant_next()

      task = asyncio.create_task(expire(pending_grant_sid))
      background_tasks.add(task)
      task.add_done_callback(background_tasks.discard)

    async def handle_session_message(sid: str, text: str) -> None:
      """A control or heartbeat message from one browser (/state text)."""
      nonlocal claiming_ui_ws, pending_grant_sid, max_spectators
      last_heartbeat[sid] = loop_time()
      if text == _SessionMessage.REQUEST_CONTROL:
        if sid != controller_sid and sid not in control_queue:
          control_queue.append(sid)
          await grant_next()
          await broadcast_roster()
      elif text == _SessionMessage.LEAVE_QUEUE:
        if sid in control_queue:
          control_queue.remove(sid)
          await broadcast_roster()
      elif text == _SessionMessage.FORCE_CONTROL:
        if sid != controller_sid:
          logger.info("[Session] %s forces control", sid)
          if sid in control_queue:
            control_queue.remove(sid)
          pending_grant_sid = sid
          if active_ui_ws is not None:
            # The bridge teardown frees the slot and grant_next honors the
            # pending claim; the ousted page settles into spectating.
            await active_ui_ws.close(
                _WS_CLOSE_CONTROLLER_TAKEN, "control taken"
            )
          elif claiming_ui_ws is not None:
            claiming = claiming_ui_ws
            claiming_ui_ws = None
            await claiming.close(_WS_CLOSE_CONTROLLER_TAKEN, "control taken")
            await grant_next()
          else:
            await grant_next()
      elif text == _SessionMessage.HEARTBEAT:
        pass  # last_heartbeat is updated for every message.
      elif text.startswith(_MAX_SPECTATORS_PREFIX):
        if sid != controller_sid:
          return  # Only the controller sets the limit.
        try:
          value = int(text[len(_MAX_SPECTATORS_PREFIX) :])
        except ValueError:
          return
        max_spectators = max(0, min(_MAX_SPECTATOR_HARD_CAP, value))
        logger.info("[Session] Spectator limit set to %s", max_spectators)
        # Enforce the new limit immediately, kicking the newest spectators
        # first. A kicked page shows the session-full notice and retries,
        # so it walks back in when a slot frees up.
        excess = len(state_clients) - (max_spectators + 1)
        for kick_sid in reversed(list(state_clients)):
          if excess <= 0:
            break
          if kick_sid == controller_sid:
            continue
          client = state_clients.get(kick_sid)
          if client is not None:
            logger.info("[Session] Kicking spectator over the new limit")
            try:
              await client.close(_WS_CLOSE_SESSION_FULL, "session full")
            except (ConnectionClosed, ConnectionError):
              pass
          excess -= 1
        await broadcast_roster()
      elif text.startswith(_THEME_PREFIX):
        if sid != controller_sid:
          return  # Only the controller drives the remote UI.
        theme = text[len(_THEME_PREFIX) :]
        if theme in _THEMES:
          server.set_theme(theme)

    async def enforce_activity() -> None:
      """Releases a silent controller when someone waits; kicks silent tabs."""
      while True:
        await asyncio.sleep(5.0)
        now = loop_time()
        if (
            active_ui_ws is not None
            and last_controller_input[0] > 0
            and now - last_controller_input[0] > _CONTROLLER_SILENT_KICK_SEC
            and (control_queue or pending_grant_sid)
        ):
          logger.info("[Session] Releasing control from an inactive controller")
          await active_ui_ws.close(_WS_CLOSE_CONTROLLER_TAKEN, "inactive")
        for sid, client in list(state_clients.items()):
          if sid == controller_sid:
            continue
          seen = last_heartbeat.get(sid, now)
          if now - seen > _SPECTATOR_SILENT_KICK_SEC:
            logger.info("[Session] Kicking inactive spectator %s", sid)
            try:
              await client.close(_WS_CLOSE_INACTIVE, "inactive")
            except (ConnectionClosed, ConnectionError):
              pass

    # --- /ui: stream the headless UI to the controlling browser -------------

    async def ui_handler(ws: ServerConnection) -> None:
      nonlocal active_ui_ws, claiming_ui_ws, controller_sid, pending_grant_sid
      nonlocal ui_rejection_logged
      ui = server.ui
      if ui is None:
        await ws.close(_WS_CLOSE_CONTROLLER_TAKEN, "controller unavailable")
        return
      if active_ui_ws is not None or claiming_ui_ws is not None:
        # One controller at a time. The rejected browser spectates and may retry
        # via its "Request control" button once the controller leaves.
        logger.debug("[UiStream] Controller slot taken; rejecting new browser")
        await ws.close(_WS_CLOSE_CONTROLLER_TAKEN, "controller slot taken")
        return
      sid = _session_id(ws)
      if pending_grant_sid is not None and sid != pending_grant_sid:
        # The slot is reserved for a granted page (queue fairness).
        await ws.close(_WS_CLOSE_CONTROLLER_TAKEN, "controller slot reserved")
        return

      claiming_ui_ws = ws
      session_started = False
      try:
        # Handshake: the browser's Hello message, answered with the UI's. A
        # new session then re-sends everything the browser needs. Only promote
        # this browser to controller once its handshake has been validated, so
        # stalled or incompatible clients cannot flip the session roster.
        try:
          handshake = await asyncio.wait_for(
              ws.recv(), timeout=_HANDSHAKE_TIMEOUT_SEC
          )
        except asyncio.TimeoutError:
          await ws.close(CloseCode.POLICY_VIOLATION, "handshake timeout")
          return
        if not isinstance(handshake, bytes):
          await ws.close(CloseCode.POLICY_VIOLATION, "expected a handshake")
          return
        if claiming_ui_ws is not ws:
          return
        try:
          reply = ui.start_session(handshake)
        except ValueError as e:
          # Such a page (e.g. one still running an older client) retries every
          # second: say why once.
          if not ui_rejection_logged:
            ui_rejection_logged = True
            logger.warning("[UiStream] Rejected a browser: %s", e)
          await ws.close(CloseCode.POLICY_VIOLATION, _close_reason(str(e)))
          return
        session_started = True
        await ws.send(reply)
        if claiming_ui_ws is not ws:
          return

        claiming_ui_ws = None
        if sid == pending_grant_sid:
          pending_grant_sid = None
        if sid in control_queue:
          control_queue.remove(sid)
        active_ui_ws = ws
        controller_sid = sid
        last_controller_input[0] = loop_time()
        await broadcast_roster()
        logger.debug("[UiStream] Session started.")

        # See _UI_ACK_PREFIX: one frame in flight at a time. The UI keeps
        # capturing frames meanwhile; only the newest is sent once the browser
        # has the last one, so a slow link shows a fresh UI, not a backlog.
        frame_acked = asyncio.Event()
        frame_acked.set()
        frame_sent_at = 0.0  # Loop time at which the last frame went out.
        frame_sent_ack = ""  # The browser's ack of that frame.

        async def send_frames() -> None:
          nonlocal frame_sent_at, frame_sent_ack
          while True:
            await ui_frame_ready.wait()
            try:
              await asyncio.wait_for(
                  frame_acked.wait(), timeout=_ACK_TIMEOUT_SEC
              )
            except asyncio.TimeoutError:
              # A page that still draws sends input every frame, so its ack was
              # lost: send anyway rather than stall. A hidden tab draws nothing
              # (no input, no ack) and would only pile frames up unread: keep
              # waiting until it draws again.
              if last_controller_input[0] <= frame_sent_at:
                continue
            ui_frame_ready.clear()
            messages = ui.take_messages()
            if messages:  # Ends with a frame (textures, if any, go first).
              frame_acked.clear()
              frame_sent_at = loop_time()
              frame_sent_ack = f"{_UI_ACK_PREFIX}{ui.last_frame_index()}"
            for message in messages:
              await ws.send(message)

        async def receive_input() -> None:
          async for message in ws:
            if isinstance(message, bytes):
              last_controller_input[0] = loop_time()
              ui.push_input(message)
            elif message == frame_sent_ack:  # Not a late ack of an older one.
              frame_acked.set()

        done, pending = await asyncio.wait(
            [
                asyncio.create_task(send_frames()),
                asyncio.create_task(receive_input()),
            ],
            return_when=asyncio.FIRST_COMPLETED,
        )
        for task in pending:
          task.cancel()
        for task in done:
          task.exception()  # Retrieve to avoid "exception never retrieved".
      except (ConnectionClosed, ConnectionError):
        pass
      finally:
        logger.debug("[UiStream] Session ended.")
        was_claiming = claiming_ui_ws is ws
        if was_claiming:
          claiming_ui_ws = None
        if session_started:
          ui.end_session()
        if active_ui_ws is ws:
          active_ui_ws = None
          controller_sid = None
          await grant_next()
          await broadcast_roster()
        elif (
            was_claiming
            and active_ui_ws is None
            and pending_grant_sid is None
            and control_queue
        ):
          await grant_next()

    # --- /state: latest-wins payload broadcast --------------------------------

    async def state_handler(ws: ServerConnection) -> None:
      nonlocal pending_grant_sid
      sid = _session_id(ws)
      # A page reconnecting after a network blip keeps its sid; its stale entry
      # (dead socket, not yet cleaned up) must not count against the limit,
      # since installing the new socket merely replaces it. Only a genuinely new
      # sid consumes a slot.
      if sid not in state_clients and len(state_clients) > max_spectators:
        logger.info("[StateWS] Session full; rejecting browser")
        await ws.close(_WS_CLOSE_SESSION_FULL, "session full")
        return
      state_clients[sid] = ws
      server._viewer_count = len(state_clients)  # pylint: disable=protected-access
      last_heartbeat[sid] = loop_time()
      logger.info("[StateWS] Browser connected (%d total)", len(state_clients))
      await broadcast_roster()

      def read_state() -> tuple[int, bytes] | None:
        """Reads the latest state payload from the server instance.

        In the thread model, the viewer thread writes server._state_payload and
        bumps server._state_generation (via WebServer.update_state()) under
        server._state_lock; this side just grabs a snapshot.  Returns
        (generation, payload) or None.
        """
        with server._state_lock:
          gen = server._state_generation
          data = server._state_payload
        if data is None:
          return None
        return gen, data

      # See _STATE_ACK_MESSAGE: at most _STATE_MAX_IN_FLIGHT payloads in flight
      # at a time, so the latest-wins read below ships the freshest state a slow
      # link can carry without stalling 60Hz ticks over ~20-50ms proxy RTTs.
      payload_acked = asyncio.Event()
      payload_acked.set()
      in_flight = 0
      # Set initially so a browser that connects between payloads gets the
      # current one right away.
      state_ready = asyncio.Event()
      state_ready.set()
      state_waiters.add(state_ready)

      async def send_payloads() -> None:
        nonlocal in_flight
        last_gen = 0
        # The bundles this browser may prefetch: sent on join and again
        # whenever its list changes (add_model wakes the stream like a payload
        # does), so a late joiner and a long-running page see the same list.
        # The page starts with an empty queue, so a bare line is only sent to
        # clear a list it was sent earlier.
        last_models_gen = -1
        last_prefetch_line = _PREFETCH_PREFIX
        while True:
          await state_ready.wait()
          try:
            await asyncio.wait_for(
                payload_acked.wait(), timeout=_ACK_TIMEOUT_SEC
            )
          except asyncio.TimeoutError:
            in_flight = 0
            payload_acked.set()  # Lost ack; send anyway rather than stalling forever.
          # Cleared before the read: an update racing with it sets the event
          # again and is picked up on the next pass instead of being lost.
          state_ready.clear()
          models_gen = server.models_generation
          if models_gen != last_models_gen:
            last_models_gen = models_gen
            prefetch_line = server.prefetch_line()
            if prefetch_line != last_prefetch_line:
              last_prefetch_line = prefetch_line
              await ws.send(prefetch_line)
          result = read_state()
          if result is None or result[0] == last_gen:
            continue
          last_gen, data = result
          in_flight += 1
          if in_flight >= _STATE_MAX_IN_FLIGHT:
            payload_acked.clear()
          await ws.send(data)

      async def recv_messages() -> None:
        nonlocal in_flight
        async for message in ws:
          if isinstance(message, bytes):
            # The controller's locally moved camera, a ClientCameraMessage
            # (state_payload.h) for the viewer thread to adopt.
            if sid == controller_sid:
              server.set_client_camera(message)
            continue
          if isinstance(message, str):
            if message == _STATE_ACK_MESSAGE:
              # Deliberately does NOT count as liveness: acks keep flowing from
              # hidden tabs (WebSocket events are not requestAnimationFrame
              # gated), and the inactivity policy must still see those tabs as
              # silent.
              in_flight = max(0, in_flight - 1)
              if in_flight < _STATE_MAX_IN_FLIGHT:
                payload_acked.set()
              continue
            await handle_session_message(sid, message)

      try:
        done, pending = await asyncio.wait(
            [
                asyncio.create_task(send_payloads()),
                asyncio.create_task(recv_messages()),
            ],
            return_when=asyncio.FIRST_COMPLETED,
        )
        for task in pending:
          task.cancel()
        for task in done:
          task.exception()  # Retrieve to avoid "exception never retrieved".
      except (ConnectionClosed, ConnectionError):
        pass
      finally:
        state_waiters.discard(state_ready)
        # Only tear down if this socket is still the one registered for sid: a
        # reconnect may have already replaced it, and that newer connection now
        # owns the queue and heartbeat entries.
        if state_clients.get(sid) is ws:
          del state_clients[sid]
          server._viewer_count = len(state_clients)  # pylint: disable=protected-access
          if sid in control_queue:
            control_queue.remove(sid)
          last_heartbeat.pop(sid, None)
          if (
              pending_grant_sid == sid
              and active_ui_ws is None
              and claiming_ui_ws is None
          ):
            pending_grant_sid = None
            await grant_next()
          logger.info(
              "[StateWS] Browser disconnected (%d total)", len(state_clients)
          )
          await broadcast_roster()

    # --- Dispatch ----------------------------------------------------------

    def process_request(
        connection: ServerConnection, request: Request
    ) -> Response | None:
      del connection

      # Split path and query string.
      if "?" in request.path:
        path, query_string = request.path.split("?", 1)
      else:
        path, query_string = request.path, ""
      if path in ("/ui", "/state", "/drop"):
        # Plain HTTP requests to a WebSocket path (e.g. browser speculative probe
        # or proxy without Upgrade header) get a clean 426 Upgrade Required
        # instead of triggering websockets' opening-handshake exception log.
        connection_opts = [
            opt.strip().lower()
            for val in request.headers.get_all("Connection")
            for opt in val.split(",")
        ]
        if "upgrade" not in connection_opts:
          headers = Headers()
          headers["Upgrade"] = "websocket"
          headers["Connection"] = "Upgrade"
          return Response(
              426,
              "Upgrade Required",
              headers,
              b"WebSocket upgrade required\n",
          )
        return None  # Proceed with the WebSocket handshake.

      if path == "/model":
        return _serve_model(query_string)

      return _serve_http(path)

    def process_response(
        connection: ServerConnection, request: Request, response: Response
    ) -> Response | None:
      """Adds cross-origin headers to the WebSocket upgrade (101) response.

      The page serves Cross-Origin-Opener-Policy: same-origin and
      Cross-Origin-Embedder-Policy: require-corp so the WASM pthread build
      can use SharedArrayBuffer. When accessed through an HTTPS reverse proxy,
      the browser's cross-origin isolation policy blocks WebSocket connections
      unless the upgrade response carries matching headers. Without them, the
      handshake fails with close code CloseCode.ABNORMAL_CLOSURE.

      Args:
        connection: The WebSocket server connection (unused).
        request: The initial HTTP upgrade request (unused).
        response: The HTTP upgrade response to attach CORS headers to.

      Returns:
        None to allow the WebSocket upgrade handshake to proceed.
      """
      del connection
      del request
      response.headers["Cross-Origin-Opener-Policy"] = "same-origin"
      response.headers["Cross-Origin-Embedder-Policy"] = "require-corp"
      response.headers["Access-Control-Allow-Origin"] = "*"
      response.headers["Cross-Origin-Resource-Policy"] = "cross-origin"
      return None

    # --- /drop: receive a file dropped onto the browser page ---------------

    async def drop_handler(ws: ServerConnection) -> None:
      """Receives dropped files and forwards them to the viewer process.

      The browser opens this socket on demand and sends one binary frame per
      file ([u32 path length][relative path utf-8][file bytes], see
      index.html), then an empty frame as an end marker; this server closes
      once it has everything. The files cross to the viewer process via
      drop_queue as a dict of relative path -> bytes; WebViewer.get_drop_file()
      writes them to a temporary directory for the regular drop-loading flow.

      Loading a model changes the session for every connected page, so only
      the controller may do it; drops from other pages are rejected.

      Args:
        ws: The WebSocket connection to receive from.
      """
      if controller_sid is None or _session_id(ws) != controller_sid:
        logger.info("[Drop] Ignored a model drop from a non-controller page")
        await ws.close(_WS_CLOSE_NOT_CONTROLLER, "not the controller")
        return

      files: dict[str, bytes] = {}
      complete = False
      try:
        async for message in ws:
          if not isinstance(message, bytes):
            continue
          if not message:
            complete = True  # End-of-drop marker.
            break
          if len(message) < 4:
            continue
          (name_len,) = struct.unpack_from("<I", message)
          if 4 + name_len > len(message):
            continue
          name = message[4 : 4 + name_len].decode("utf-8", "replace")
          files[name] = message[4 + name_len :]
      except (ConnectionClosed, ConnectionError):
        pass

      # Only forward a drop that arrived in full. A connection that dies before
      # the end marker (e.g. a file frame exceeding the websocket size cap
      # closes it with CloseCode.MESSAGE_TOO_BIG) leaves a partial file set that
      # would load as a broken model, so discard it instead.
      if not complete:
        if files:
          logger.info(
              "[Drop] Incomplete drop (%d file(s) before the"
              " connection closed); discarding.",
              len(files),
          )
      elif files and server.drop_queue is not None:
        total = sum(len(data) for data in files.values())
        logger.info("[Drop] Received %d file(s), %d bytes", len(files), total)
        server.drop_queue.put(files)

      await ws.close()

    async def ws_handler(ws: ServerConnection) -> None:
      req = ws.request
      if req is None:
        await ws.close(CloseCode.POLICY_VIOLATION, "missing request")
        return
      path = req.path.split("?")[0]
      if path == "/ui":
        await ui_handler(ws)
      elif path == "/state":
        await state_handler(ws)
      elif path == "/drop":
        await drop_handler(ws)
      else:
        await ws.close(CloseCode.POLICY_VIOLATION, "unknown endpoint")

    # Block until the stop event is set by WebServer.stop(). The server thread
    # is a daemon, so it also dies if the process exits for any reason.
    async def watch_stop() -> None:
      loop = asyncio.get_running_loop()
      stopped = asyncio.Event()
      with server._state_lock:  # pylint: disable=protected-access
        server._wake_stop = (  # pylint: disable=protected-access
            functools.partial(loop.call_soon_threadsafe, stopped.set)
        )
        if stop_event.is_set():
          stopped.set()
      try:
        await stopped.wait()
      finally:
        with server._state_lock:  # pylint: disable=protected-access
          server._wake_stop = None  # pylint: disable=protected-access
      logger.debug("[Http] Stop event received; shutting down.")

    # The UI codec does its own delta compression and the state payload is
    # small; permessage-deflate would only add latency at 60Hz.
    ws_server = await serve(
        ws_handler,
        sock=http_sock,
        process_request=process_request,
        process_response=process_response,
        compression=None,
        ping_interval=None,
        ping_timeout=None,
        open_timeout=None,
        close_timeout=None,
        # Big enough for model files uploaded via /drop.
        max_size=2**26,
    )
    http_host, http_port = http_sock.getsockname()[:2]
    logger.debug(
        "[Http] Serving on http://%s:%d (/, /model, /ui, /state, /drop)",
        http_host,
        http_port,
    )

    enforcer = asyncio.create_task(enforce_activity())
    try:
      await watch_stop()
    finally:
      server._viewer_count = 0  # pylint: disable=protected-access
      server._wake_state_streams = None
      enforcer.cancel()
      server._wake_ui_stream = None  # pylint: disable=protected-access
      if server.stop_reason:
        # Tell the browsers why the viewer stopped, so the page can show it;
        # ws_server.close() below only says "going away". Bounded: a browser
        # that never answers the close handshake must not hold up teardown.
        reason = _close_reason(server.stop_reason)
        try:
          await asyncio.wait_for(
              asyncio.gather(
                  *(
                      ws.close(_WS_CLOSE_VIEWER_ERROR, reason)
                      for ws in list(state_clients.values())
                  ),
                  return_exceptions=True,
              ),
              timeout=1.0,
          )
        except asyncio.TimeoutError:
          pass
      # Close listeners explicitly to prevent hanging on open client sockets.
      ws_server.close()

  _run_cancellable(main_loop)


class WebServer:
  """The Web Viewer's single-port server.

  Serves the browser page, WASM, and model over HTTP; streams the headless UI at
  /ui; and broadcasts the state payload at /state on a single public port from a
  background daemon thread.  State payloads are handed over through a
  lock-protected reference with latest-wins semantics: update_state() may be
  called at any rate from the viewer thread; browsers only ever see the newest
  payload.  The server thread is started once and persists.  When the model
  changes, update_model() swaps the bytes served at /model, without any restart.
  Models that may be shown soon can be announced with add_model(): browsers
  download them in the background and switch to them without a download.

  Run the simulation with the web viewer, then visit the printed URL.
  """

  def __init__(
      self,
      http_sock: socket.socket,
      ui: UiSession | None = None,
      static_files_dir: str | None = None,
      mjb_data: bytes | None = None,
      drop_queue: queue.Queue[Any] | None = None,
  ) -> None:
    """Initializes the server around a pre-bound listening socket.

    The socket is bound by the viewer (see bind_public_socket) and shared with
    the server thread, so bind failures can't occur here.

    Args:
      http_sock: The listening socket for HTTP and WebSocket traffic.
      ui: The headless UI to stream at /ui. Without it, /ui rejects browsers.
      static_files_dir: The directory containing the static files to serve.
      mjb_data: The model data to serve from /model.
      drop_queue: The queue to put dropped files onto.
    """
    self.http_sock = http_sock
    self.ui = ui
    self.static_files_dir = static_files_dir or _find_static_files_dir()
    self.mjb_data = mjb_data

    # Dropped-file bytes travel from the server thread back to the viewer thread
    # through this queue.
    self.drop_queue = drop_queue

    # State payload: the viewer thread writes, the server thread reads.
    self._state_lock = threading.Lock()
    self._state_payload: bytes | None = None
    self._state_generation: int = 0
    self._viewer_count: int = 0
    self._wake_state_streams: Callable[[], Any] | None = None
    self._client_camera: bytes | None = None
    self._pending_theme: str | None = None

    # Model bundles by crc32 (see _serve_model), least recently used first,
    # including the current model. add_model() announces bundles browsers may
    # prefetch; the announced ones that have not become current since are kept
    # in announcement order (latest last). The generation bumps whenever the
    # prefetch line changes so the /state streams know to resend it.
    self.model_cache_bytes = _MODEL_CACHE_BYTES_DEFAULT
    self._models_lock = threading.Lock()
    self._models: collections.OrderedDict[int, bytes] = (
        collections.OrderedDict()
    )
    self._announced: collections.OrderedDict[int, None] = (
        collections.OrderedDict()
    )
    self._models_generation: int = 0
    self._current_crc32: int = 0
    if mjb_data:
      self.update_model(mjb_data)

    # Wakes the /ui stream's sender; set while the server's event loop runs.
    self._wake_ui_stream: Callable[[], Any] | None = None
    self._wake_stop: Callable[[], Any] | None = None

    self._stop_event = threading.Event()
    self._thread: threading.Thread | None = None
    # Why the viewer stopped, when not normally (see stop()); read by the
    # server thread as it shuts down.
    self.stop_reason = ""

  def update_state(self, payload: bytes) -> None:
    """Publishes the latest state payload. Called from the viewer thread."""
    with self._state_lock:
      self._state_payload = payload
      self._state_generation += 1
    self._wake()

  def _wake(self) -> None:
    """Wakes the /state streams; a no-op while the server thread is down."""
    # Hop to the server thread's event loop to wake the /state streams; unset
    # while the server thread is not running.
    wake = self._wake_state_streams
    if wake is not None:
      try:
        wake()
      except RuntimeError:
        pass  # The server's event loop has just closed.

  def notify_ui_frame(self) -> None:
    """Tells the /ui stream that the UI has a new frame for the browser.

    Called from the viewer thread after each HeadlessUi.end_frame(), so the
    frame goes out as soon as the browser can take it.
    """
    wake = self._wake_ui_stream
    if wake is None:
      return
    try:
      wake()
    except RuntimeError:
      pass  # The server's event loop has just closed.

  def update_model(self, mjb_data: bytes, crc32: int | None = None) -> None:
    """Makes ``mjb_data`` the current model, served at /model.

    The bundle also joins the cache under its crc32, so late-joining browsers
    can prefetch it and nothing evicts it while it is current.

    Args:
      mjb_data: The model bundle to serve.
      crc32: The bundle's crc32 (which must match the one stamped into state
        payloads), or None to compute it here.
    """
    self.mjb_data = mjb_data
    self._add_model(mjb_data, crc32, current=True)

  def add_model(self, mjb_data: bytes, crc32: int | None = None) -> int:
    """Caches a bundle at /model?crc32=... and tells browsers to prefetch it.

    Browsers download announced bundles in announcement order; announcing a
    bundle again moves it to the end. The least recently used bundles (other
    than the current model) are dropped once the cache exceeds
    model_cache_bytes, where adding, switching to, and serving a bundle all
    count as uses.

    Args:
      mjb_data: The model bundle.
      crc32: The bundle's crc32, or None to compute it here.

    Returns:
      The bundle's crc32.
    """
    return self._add_model(mjb_data, crc32, current=False)

  def _add_model(
      self, mjb_data: bytes, crc32: int | None, current: bool
  ) -> int:
    """Caches a bundle, making it the current model if ``current``."""
    if crc32 is None:
      crc32 = zlib.crc32(mjb_data)
    with self._models_lock:
      before = self._prefetch_items()
      if crc32 in self._models:
        self._models.move_to_end(crc32)  # Most recently used.
      else:
        self._models[crc32] = mjb_data
      if current:
        self._current_crc32 = crc32
        self._announced.pop(crc32, None)  # On screen: no longer upcoming.
      else:
        self._announced[crc32] = None
        self._announced.move_to_end(crc32)  # Latest announcement last.
      total = sum(len(data) for data in self._models.values())
      for old_crc32 in list(self._models):
        if total <= self.model_cache_bytes:
          break
        if old_crc32 not in (crc32, self._current_crc32):
          total -= len(self._models.pop(old_crc32))
          self._announced.pop(old_crc32, None)
      changed = self._prefetch_items() != before
      if changed:
        self._models_generation += 1
    if changed:
      self._wake()
    return crc32

  def _prefetch_items(self) -> list[tuple[int, int]]:
    """Returns (crc32, size) of the bundles browsers may prefetch, in order.

    Upcoming models (announced and not shown since) come first, in
    announcement order, followed by previously shown models, most recently
    used first. The current model is left out: every browser already has it,
    or is about to fetch it because its state payloads name it. Call with
    _models_lock held.
    """
    current = self._current_crc32
    upcoming = [c for c in self._announced if c != current]
    shown = [
        c
        for c in reversed(self._models)
        if c != current and c not in self._announced
    ]
    return [(c, len(self._models[c])) for c in upcoming + shown]

  def cached_model(self, crc32: int) -> bytes | None:
    """Returns the cached bundle with this crc32, or None.

    Serving a bundle counts as a use for eviction (see add_model).
    """
    with self._models_lock:
      data = self._models.get(crc32)
      if data is not None:
        self._models.move_to_end(crc32)
      return data

  @property
  def viewer_count(self) -> int:
    """Number of browsers currently connected to the /state stream."""
    return self._viewer_count

  @property
  def models_generation(self) -> int:
    """Counts changes to the prefetch line; see prefetch_line()."""
    return self._models_generation

  def prefetch_line(self) -> str:
    """Returns the prefetch line for browsers; see _PREFETCH_PREFIX.

    Lists the bundles in the order to download them (see _prefetch_items); a
    bare "prefetch=" while nothing but the current model is cached.
    """
    with self._models_lock:
      items = self._prefetch_items()
    return _PREFETCH_PREFIX + ",".join(f"{c}:{n}" for c, n in items)

  def set_theme(self, theme: str) -> None:
    """Records a UI theme picked by the controller browser."""
    with self._state_lock:
      self._pending_theme = theme

  def pop_theme(self) -> str | None:
    """Returns and clears any UI theme picked by the controller browser."""
    with self._state_lock:
      theme = self._pending_theme
      self._pending_theme = None
      return theme

  def set_client_camera(self, camera: bytes) -> None:
    """Records the latest camera sent by the controlling browser."""
    with self._state_lock:
      self._client_camera = camera

  def take_client_camera(self) -> bytes | None:
    """Returns the camera the controller last sent, once; else None."""
    with self._state_lock:
      camera, self._client_camera = self._client_camera, None
    return camera

  def start(self) -> None:
    """Starts the server on a background daemon thread."""
    if not self.static_files_dir:
      logger.warning(
          "[Http] Could not find web viewer static files; install"
          " 'mujoco-studio-wasm' or set MUJOCO_WEB_VIEWER_DIST."
      )
      return

    logger.debug("[Http] Serving web viewer from: %s", self.static_files_dir)

    self._stop_event.clear()
    self._thread = threading.Thread(
        target=_run_server,
        args=(self, self._stop_event),
        daemon=True,
    )
    self._thread.start()

  def stop(self, reason: str = "") -> None:
    """Stops the server thread.

    Args:
      reason: Why the viewer stopped, when this is not a normal exit: a one-line
        summary of the exception that ended it. Sent to the connected browsers,
        which show it on the page.
    """
    self.stop_reason = reason
    with self._state_lock:
      self._stop_event.set()
      wake = self._wake_stop
    if wake is not None:
      try:
        wake()
      except RuntimeError:
        pass
    if self._thread is not None:
      self._thread.join(timeout=5.0)
      self._thread = None
